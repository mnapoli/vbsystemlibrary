Attribute VB_Name = "modAPI"
'---------------------------------------------------------------------------------------
' Module    : modAPI
' DateTime  : 22/11/2006 23:02
' Author    : Vb System Library
' Copyright : (C) 2007 L'�quipe Vb System Library
'              See "modPresentation" for more information
' Purpose   : Regroupe toutes les d�clarations d'API, de constantes et de types
'---------------------------------------------------------------------------------------

Option Explicit



'---------------------------------------------------------------------------------------
' Divers

Public Type POINTAPI
    x As Long
    Y As Long
End Type
Public Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long
Public Const MAX_PATH As Integer = 260
Public Declare Function GetSecurityInfo Lib "advapi32.dll" (ByVal hObject As Long, ByVal ObjectType As Long, ByVal SecurityInformation As Long, ppsidOwner As Long, ppsidGroup As Long, ppDacl As Long, ppSacl As Long, ppSecurityDescriptor As Long) As Long
Public Declare Function LookupAccountSid Lib "advapi32.dll" Alias "LookupAccountSidA" (ByVal lpSystemName As String, ByVal Sid As Long, ByVal Name As String, cbName As Long, ByVal ReferencedDomainName As String, cbReferencedDomainName As Long, peUse As Long) As Long
Public Const SE_KERNEL_OBJECT As Long = 6
Public Const OWNER_SECURITY_INFORMATION As Long = 1
Public Const GROUP_SECURITY_INFORMATION As Long = 2
Public Declare Function GetProcAddress Lib "kernel32" (ByVal hModule As Long, ByVal lpProcName As String) As Long
Public Const KRN_LOAD  As String = "LoadLibraryA"
Public Const KRN_FREE  As String = "FreeLibrary"
Public Const KRN_DLL   As String = "Kernel32"
Public Const GET_HMOD  As String = "GetModuleHandleA"
Public Declare Function WaitForSingleObject Lib "kernel32" (ByVal hHandle As Long, ByVal dwMilliseconds As Long) As Long

' Manipuler la m�moire
Public Declare Sub CopyMemory Lib "kernel32.dll" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)
Public Declare Sub MoveMemory Lib "kernel32.dll" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)
Public Declare Function lstrlen Lib "kernel32.dll" Alias "lstrlenA" (ByVal lpString As Long) As Long
Public Declare Function lstrcpy Lib "kernel32.dll" Alias "lstrcpyA" (ByVal lpString1 As String, ByVal lpString2 As Long) As Long
Public Declare Function VirtualFreeEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, ByVal dwSize As Long, ByVal dwFreeType As Long) As Long
Public Declare Function VirtualAllocEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, ByVal dwSize As Long, ByVal flAllocationType As Long, ByVal flProtect As Long) As Long
Public Const MEM_RELEASE = &H8000
Public Const MEM_FREE = &H10000
Public Const MEM_COMMIT = &H1000
Public Const MEM_PRIVATE = &H20000
Public Const PAGE_READWRITE = &H4

' Pour lister les process, modules, threads
Public Declare Function CreateToolhelp32Snapshot Lib "kernel32.dll" (ByVal dwFlags As Long, ByVal th32ProcessID As Long) As Long
Public Const TH32CS_SNAPMODULE As Long = &H8    'modules du processus

' Renvoie l'adresse du descripteur de tableau
Public Declare Function VarPtrArray Lib "msvbvm60.dll" Alias "VarPtr" (Arr() As Any) As Long
' Constante pour descripteur de tableau
Public Const FADF_AUTO = 1
Public Const FADF_FIXEDSIZE = 16
Public Const FADF_STATIC = 2
' Descripteur de tableau
Public Type SafeArray1d
    cDims As Integer        'nombre de dimensions
    fFeatures As Integer    'falgs
    cbElements As Long      'taille des elements
    cLocks As Long          'tableau non redimensionnable
    pvData As Long          'pointeur vers les donn�es du tableau
    cElements As Long       'nombre d'elements
    lLbound As Long         'limite basse
End Type
' Informations sur une plage m�moire
Public Type MEMORY_BASIC_INFORMATION ' 28 bytes
    BaseAddress         As Long     ' Adresse de la plage m�moire
    AllocationBase      As Long
    AllocationProtect   As Long
    RegionSize          As Long     ' Taille en octets de la plage m�moire
    State               As Long
    Protect             As Long     ' Protection d'acc�s � la plage m�moire
    lType               As Long
End Type
' Constantes pour lType
Public Declare Function VirtualQueryEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, lpBuffer As MEMORY_BASIC_INFORMATION, ByVal dwLength As Long) As Long
Public Declare Sub GetSystemInfo Lib "kernel32" (lpSystemInfo As SYSTEM_INFO)
Public Type SYSTEM_INFO ' 36 Bytes
    dwOemID                     As Long     ' Obsolete
    dwPageSize                  As Long
    lpMinimumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus petite accessible aux applications et DLL
    lpMaximumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus grande accessible aux applications et DLL
    dwActiveProcessorMask       As Long
    dwNumberOrfProcessors       As Long     ' Nombre de processeurs dans le systeme
    dwProcessorType             As Long
    dwAllocationGranularity     As Long
    wProcessorLevel             As Integer
    wProcessorRevision          As Integer
End Type
' NtQuerySystemInformation
Public Declare Function NtQuerySystemInformation Lib "NTDLL.DLL" (ByVal SystemInformationClass As Long, ByVal SystemInformation As Long, ByVal SystemInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function NtSetSystemInformation Lib "NTDLL.DLL" (ByVal SystemInformationClass As Long, ByVal SystemInformation As Long, ByVal SystemInformationLength As Long) As Long
Public Const SystemCacheInformation As Long = 21


'---------------------------------------------------------------------------------------
' Processus
' Permet d'obtenir un handle d'un processus particulier
Public Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInheritHandle As Long, ByVal dwProcessId As Long) As Long
' Constantes d'acc�s aux processus
Public Const PROCESS_TERMINATE                  As Long = &H1
Public Const PROCESS_CREATE_THREAD              As Long = &H2
Public Const PROCESS_SET_SESSIONID              As Long = &H4
Public Const PROCESS_VM_OPERATION               As Long = &H8
Public Const PROCESS_VM_READ                    As Long = &H10
Public Const PROCESS_VM_WRITE                   As Long = &H20
Public Const PROCESS_DUP_HANDLE                 As Long = &H40
Public Const PROCESS_CREATE_PROCESS             As Long = &H80
Public Const PROCESS_SET_QUOTA                  As Long = &H100
Public Const PROCESS_SET_INFORMATION            As Long = &H200
Public Const PROCESS_QUERY_INFORMATION          As Long = &H400
Public Const PROCESS_READ_CONTROL               As Long = &H20000
Public Const SYNCHRONIZE                        As Long = &H100000
Public Const STANDARD_RIGHTS_REQUIRED           As Long = &HF0000
Public Const PROCESS_ALL_ACCESS                 As Long = (STANDARD_RIGHTS_REQUIRED Or SYNCHRONIZE Or &HFFF)
'------------------------------------
Public Declare Function TerminateProcess Lib "kernel32" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long
Public Declare Function GetExitCodeProcess Lib "kernel32" (ByVal hProcess As Long, lpExitCode As Long) As Long
Public Const STILL_ACTIVE = &H103
' Permet d'obtenir des infos sur les temps des processus
Public Declare Function GetProcessTimes Lib "kernel32" (ByVal hProcess As Long, lpCreationTime As Currency, lpExitTime As Currency, lpKernelTime As Currency, lpUserTime As Currency) As Long
' Renvoie le process courant
Public Declare Function GetCurrentProcess Lib "kernel32.dll" () As Long
' D�finir la priorit� du processus
Public Declare Function SetPriorityClass Lib "kernel32" (ByVal hProcess As Long, ByVal dwPriorityClass As Long) As Long
Public Declare Function GetPriorityClass Lib "kernel32" (ByVal hProcess As Long) As Boolean
' Constantes des priorit�s (6 niveaux de priorit�s)
Public Const IDLE_PRIORITY_CLASS            As Long = &H40      ' Basse
Public Const BELOW_NORMAL_PRIORITY_CLASS    As Long = &H4000    ' Inf�rieure � la normale
Public Const NORMAL_PRIORITY_CLASS          As Long = &H20      ' Normale
Public Const ABOVE_NORMAL_PRIORITY_CLASS    As Long = &H8000    ' Sup�rieure � la normale
Public Const HIGH_PRIORITY_CLASS            As Long = &H80      ' Haute
Public Const REALTIME_PRIORITY_CLASS        As Long = &H100     ' Temps r�el
' Pour la taille d'un processus
Public Declare Function GetProcessMemoryInfo Lib "PSAPI.DLL" (ByVal hProcess As Long, ppsmemCounters As PROCESS_MEMORY_COUNTERS, ByVal cb As Long) As Long
Public Declare Function NtQueryInformationProcess Lib "NTDLL.DLL" (ByVal ProcessHandle As Long, ByVal ProcessInformationClass As Long, ByVal ProcessInformation As Long, ByVal ProcessInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function ReadProcessMemory Lib "kernel32.dll" (ByVal hProcess As Long, ByVal lpBaseAddress As Long, ByVal lpBuffer As Long, ByVal nSize As Long, lpNumberOfBytesWritten As Long) As Long
Public Const STATUS_INFO_LENGTH_MISMATCH As Long = &HC0000004
Public Const STATUS_SUCCESS As Long = &H0&
Public Const SystemProcessesAndThreadsInformation As Long = 5&
Public Const ProcessSessionInformation As Long = 24&
Public Declare Function WriteProcessMemory Lib "kernel32" (ByVal hProcess As Long, lpBaseAddress As Any, lpBuffer As Any, ByVal nSize As Long, lpNumberOfBytesWritten As Long) As Long


'---------------------------------------------------------------------------------------
' Fenetres
Public Declare Function GetWindow Lib "user32" (ByVal hWnd As Long, ByVal wCmd As Long) As Long
Public Const GW_CHILD = 5
Public Const GW_HWNDNEXT = 2
Public Declare Function GetDesktopWindow Lib "user32" () As Long
' WindowText
Public Declare Function GetWindowTextLength Lib "user32" Alias "GetWindowTextLengthA" (ByVal hWnd As Long) As Long
Public Declare Function GetWindowText Lib "user32" Alias "GetWindowTextA" (ByVal hWnd As Long, ByVal lpString As String, ByVal cch As Long) As Long
Public Declare Function SetWindowText Lib "user32" Alias "SetWindowTextA" (ByVal hWnd As Long, ByVal lpString As String) As Long
' WindowLong
Public Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hWnd As Long, ByVal nIndex As Long) As Long
Public Declare Function SetWindowLong Lib "user32" Alias "SetWindowLongA" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
' Renvoie la fen�tre propri�taire de la fen�tre
Public Const GWL_HWNDPARENT As Long = -8
'renvoie les styles de la fen�tre
Public Const GWL_STYLE      As Long = -16
'renvoie les styles �tendus de la fen�tre
Public Const GWL_EXSTYLE    As Long = -20
' Pour la transparence
Public Const WS_EX_LAYERED = &H80000
Public Declare Function SetLayeredWindowAttributes Lib "user32" (ByVal hWnd As Long, ByVal crKey As Long, ByVal bAlpha As Byte, ByVal dwFlags As Long) As Boolean
Public Const LWA_COLORKEY = &H1
Public Const LWA_ALPHA = &H2
' Pour connaitre les dimensions et positions de la fenetre
Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
' Activer toujours la fen�tre au dessus des autres
Public Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal x As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Const SWP_NOSIZE = &H1
Public Const SWP_NOMOVE = &H2
Public Const HWND_TOP = 0
Public Const HWND_TOPMOST = -1
Public Const HWND_NOTOPMOST = -2
' Le placement d'une fenetre
Public Declare Function GetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpWndPl As WINDOWPLACEMENT) As Long
Public Declare Function SetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpWndPl As WINDOWPLACEMENT) As Long
Public Type WINDOWPLACEMENT
    Length              As Long
    Flags               As Long
    ShowCmd             As Long
    ptMinPosition       As POINTAPI
    ptMaxPosition       As POINTAPI
    rcNormalPosition    As RECT
End Type
' Fen�tre visible ou pas
Public Declare Function IsWindowVisible Lib "user32" (ByVal hWnd As Long) As Boolean
Public Declare Function IsWindowEnabled Lib "user32" (ByVal hWnd As Long) As Boolean
' Montrer la fen�tre
Public Declare Function ShowWindowA Lib "user32" Alias "ShowWindow" (ByVal hWnd As Long, ByVal nCmdShow As Long) As Long
' Constantes associ�es :
Public Const SW_HIDE = 0
Public Const SW_SHOWNORMAL = 1
Public Const SW_SHOWMINIMIZED = 2
Public Const SW_SHOWMAXIMIZED = 3
Public Const SW_MAXIMIZE = 3
Public Const SW_SHOWNOACTIVATE = 4
Public Const SW_SHOW = 5
Public Const SW_MINIMIZE = 6
Public Const SW_SHOWNA = 8
Public Const SW_RESTORE = 9
' Envoyer un message � une fen�tre
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Public Const WM_CLOSE = &H10
' Pour activer une fen�tre avec son handle
Public Declare Function EnableWindow Lib "user32" (ByVal hWnd As Long, ByVal fEnable As Long) As Long
' Manipuler les menus d'une fen�tre
Public Declare Function GetSystemMenu Lib "user32" (ByVal hWnd As Long, ByVal bRevert As Long) As Long
Public Declare Function DrawMenuBar Lib "user32" (ByVal hWnd As Long) As Long
Public Declare Function GetMenuItemCount Lib "user32" (ByVal hMenu As Long) As Long
Public Declare Function RemoveMenu Lib "user32" (ByVal hMenu As Long, ByVal nPosition As Long, ByVal wFlags As Long) As Long
Public Const MF_BYPOSITION = &H400&
Public Const MF_REMOVE = &H1000&
' Permet de r�cup�rer le nom de classe de la fen�tre hWnd
Public Declare Function GetClassName Lib "user32.dll" Alias "GetClassNameA" (ByVal hWnd As Long, ByVal lpClassName As String, ByVal nMaxCount As Long) As Long
' R�cup�re la fenetre parente
Public Declare Function GetParent Lib "user32" (ByVal hWnd As Long) As Long
' Savoir quel thread et quel processus ont cr�� une fenetre
Public Declare Function GetWindowThreadProcessId Lib "user32" (ByVal hWnd As Long, lpdwProcessId As Long) As Long


'---------------------------------------------------------------------------------------
' Modules
Public Declare Function GetModuleFileNameEx Lib "PSAPI.DLL" Alias "GetModuleFileNameExA" (ByVal hProcess As Long, ByVal hModule As Long, ByVal lpFileName As String, ByVal nSize As Long) As Long
Public Declare Function GetModuleHandle Lib "kernel32" Alias "GetModuleHandleA" (ByVal lpModuleName As String) As Long
Public Declare Function EnumProcessModules Lib "PSAPI.DLL" (ByVal hProcess As Long, ByRef lphModule As Long, ByVal cb As Long, ByRef cbNeeded As Long) As Long
Public Declare Function Module32First Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lppe As MODULEENTRY32) As Long
Public Declare Function Module32Next Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpme As MODULEENTRY32) As Long


'---------------------------------------------------------------------------------------
' Threads
Public Declare Function Thread32First Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Declare Function Thread32Next Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Const TH32CS_SNAPTHREAD As Long = &H4&
' Pour ouvrir un thread
Public Declare Function OpenThread Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInherit As Long, ByVal dwThreadId As Long) As Long
Public Const THREAD_ALL_ACCESS = &H1F03FF
' Suspendre un thread
Public Declare Function SuspendThread Lib "kernel32" (ByVal hThread As Long) As Long
Public Declare Function ResumeThread Lib "kernel32" (ByVal hThread As Long) As Long
' Le type thread
Public Type THREADENTRY32
    dwSize As Long              'taille de cette structure (� initialiser avant l'appel � Thread32First ou Thread32Next)
    cntUsage As Long            'nombre de r�f�rence au thread
    th32ThreadID As Long        'ID du thread
    th32OwnerProcessID As Long  'ID du processus qui a cr�� le thread
    tpBasePri As Long           'priorit� initiale
    tpDeltaPri As Long          'priorit� actuelle
    dwFlags As Long             'rien de d�fini
End Type
Public Declare Function GetExitCodeThread Lib "kernel32" (ByVal hThread As Long, lpExitCode As Long) As Long
Public Declare Function CreateRemoteThread Lib "kernel32" (ByVal hProcess As Long, lpThreadAttributes As Any, ByVal dwStackSize As Long, lpStartAddress As Long, lpParameter As Any, ByVal dwCreationFlags As Long, lpThreadId As Long) As Long


'---------------------------------------------------------------------------------------
' Les Fichiers
' Actions sur un fichier
Public Declare Function DeleteFile Lib "kernel32" Alias "DeleteFileA" (ByVal lpFileName As String) As Long
' Propri�t�s d'un fichier
Public Declare Function PathFindExtension Lib "shlwapi" Alias "PathFindExtensionA" (ByVal pPath As String) As Long
' Attributs
Public Declare Function GetFileAttributes Lib "kernel32.dll" Alias "GetFileAttributesA" (ByVal lpFileName As String) As Long
Public Declare Function SetFileAttributes Lib "kernel32.dll" Alias "SetFileAttributesA" (ByVal lpFileSpec As String, ByVal dwFileAttributes As Long) As Long
Public Const FILE_INVALID_ATTRIBUTES As Long = &HFFFFFFFF
Public Const FILE_ATTRIBUTE_NORMAL As Long = &H80
' Pour r�cup�rer des infos sur les fichiers
Public Declare Function GetFileVersionInfo Lib "Version.dll" Alias "GetFileVersionInfoA" (ByVal lptstrFilename As String, ByVal dwHandle As Long, ByVal dwLen As Long, lpData As Any) As Long
Public Declare Function GetFileVersionInfoSize Lib "Version.dll" Alias "GetFileVersionInfoSizeA" (ByVal lptstrFilename As String, lpdwHandle As Long) As Long
Public Declare Function VerQueryValue Lib "Version.dll" Alias "VerQueryValueA" (pBlock As Any, ByVal lpSubBlock As String, lplpBuffer As Any, puLen As Long) As Long
Public Type VS_FIXEDFILEINFO
    dwSignature As Long
    dwStrucVersion As Long
    dwFileVersionMS As Long
    dwFileVersionLS As Long
    dwProductVersionMS As Long
    dwProductVersionLS As Long
    dwFileFlagsMask As Long
    dwFileFlags As Long
    dwFileOS As Long
    dwFileType As Long
    dwFileSubtype As Long
    dwFileDateMS As Long
    dwFileDateLS As Long
End Type
' Un argument de type Enum permet l'apparition d'une liste de
' choix lors de la saisie de l'appel de fonction.
Public Enum mfFileInfo
  fileinfoCompanyName = 0
  fileinfoFileDescription = 1
  fileinfoFileVersion = 2
  fileinfoInternalName = 3
  fileinfoLegalCopyright = 4
  fileinfoOriginalFileName = 5
  fileinfoProductName = 6
  fileinfoProductVersion = 7
End Enum
Public Declare Function SHGetSpecialFolderLocation Lib "Shell32.dll" (ByVal hwndOwner As Long, ByVal nFolder As Long, pidl As ITEMIDLIST) As Long
Public Declare Function SHGetPathFromIDList Lib "Shell32.dll" Alias "SHGetPathFromIDListA" (ByVal pidl As Long, ByVal pszPath As String) As Long
Public Declare Function GetFileSizeEx Lib "kernel32" (ByVal hFile As Long, lpFileSize As Currency) As Boolean
Public Declare Function CreateFile Lib "kernel32" Alias "CreateFileA" (ByVal lpFileName As String, ByVal dwDesiredAccess As Long, ByVal dwShareMode As Long, ByVal lpSecurityAttributes As Any, ByVal dwCreationDisposition As Long, ByVal dwFlagsAndAttributes As Long, ByVal hTemplateFile As Long) As Long
Public Const GENERIC_READ            As Long = &H80000000
Public Const FILE_SHARE_READ         As Long = &H1
Public Const FILE_SHARE_WRITE        As Long = &H2
Public Const OPEN_EXISTING           As Long = 3
Public Declare Function FindExecutable Lib "Shell32.dll" Alias "FindExecutableA" (ByVal lpFile As String, ByVal lpDirectory As String, ByVal lpResult As String) As Long
Public Type SHITEMID
    cb      As Long
    abID    As Byte
End Type
Public Type ITEMIDLIST
    mkid    As SHITEMID
End Type
' Pour les icones des fichiers
' R�cup�rer l'ic�ne associ� au fichier et le dessiner
Public Declare Function SHGetFileInfo Lib "Shell32.dll" Alias "SHGetFileInfoA" (ByVal pszPath As String, ByVal dwFileAttributes As Long, psfi As SHFILEINFO, ByVal cbFileInfo As Long, ByVal uFlags As Long) As Long
Public Type SHFILEINFO
    hIcon As Long
    iIcon As Long
    dwAttributes As Long
    szDisplayName As String * MAX_PATH
    szTypeName As String * 80
End Type
Public Declare Function ExtractAssociatedIcon Lib "Shell32.dll" Alias "ExtractAssociatedIconA" (ByVal hInst As Long, ByVal lpIconPath As String, lpiIcon As Long) As Long
Public Const DI_MASK = &H1
Public Const DI_IMAGE = &H2
Public Const DI_NORMAL = DI_MASK Or DI_IMAGE


'---------------------------------------------------------------------------------------
' Graphismes
' Permet de convertir une structure PICTDESC (et donc un handle d'image) en un IPictureDisp (= StdPicture)
Public Declare Sub OleCreatePictureIndirect Lib "oleaut32.dll" (ByRef lpPictDesc As PICTDESC, ByRef riid As GUID, ByVal fOwn As Long, ByRef lplpvObj As IPictureDisp)
' Structure d'un GUID
Public Type GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
' Structure contenant des infos sur une image
Public Type PICTDESC
    ' Normalement cette structure contient une union mais VB ne les g�re pas
    cbSizeofStruct As Long      ' Taille de cette structure
    picType As Long            ' Type d'image : ICON, BITMAP, METAFILE, ENHMETAFILE
    ' D�but union
        hImage As Long          ' Handle de l'image
        xExt As Long            ' Taille x de l'image pour une METAFILE
        yExt As Long            ' Taille y de l'image pour une METAFILE
End Type
' picType de PICTDESC pour une ICON
Public Const PICTYPE_ICON = 3
Public Declare Function ImageList_GetIcon Lib "comctl32.dll" (ByVal himl&, ByVal i&, ByVal Flags&) As Long
Public Const DJM_SMALLICON = &H6605
Public Declare Function DestroyIcon Lib "user32.dll" (ByVal hIcon As Long) As Boolean


'---------------------------------------------------------------------------------------
' L'OS
Public Declare Function GetVersionEx Lib "kernel32" Alias "GetVersionExA" (lpVersionInformation As OSVERSIONINFO) As Long
Public Type OSVERSIONINFO
    dwOSVersionInfoSize As Long
    dwMajorVersion As Long
    dwMinorVersion As Long
    dwBuildNumber As Long
    dwPlatformId As Long
    szCSDVersion As String * 128
End Type


'---------------------------------------------------------------------------------------
' Token Privileges
' R�cup�re et change les privil�ges
Public Declare Function AdjustTokenPrivileges Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal DisableAllPrivileges As Long, NewState As TOKEN_PRIVILEGES, ByVal BufferLength As Long, PreviousState As TOKEN_PRIVILEGES, ReturnLength As Long) As Long
Public Declare Function OpenProcessToken Lib "advapi32.dll" (ByVal ProcessHandle As Long, ByVal DesiredAccess As Long, TokenHandle As Long) As Long
Public Declare Function LookupPrivilegeValue Lib "advapi32.dll" Alias "LookupPrivilegeValueA" (ByVal lpSystemName As String, ByVal lpName As String, lpLuid As LUID) As Long
Public Declare Function GetTokenInformation Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal TokenInformationClass As Long, TokenInformation As Any, ByVal TokenInformationLength As Long, ReturnLength As Long) As Long
' D�claratios des Types
Public Type LUID
    LowPart As Long
    HighPart As Long
End Type
Public Type LUID_AND_ATTRIBUTES
    pLuid As LUID
    Attributes As Long
End Type
Public Type TOKEN_PRIVILEGES
    PrivilegeCount As Long
    TheLuid As LUID
    Attributes As Long
End Type
Public Type SID_IDENTIFIER_AUTHORITY
   Value(6) As Byte
End Type
Public Type SID_AND_ATTRIBUTES
   Sid          As Long
   Attributes   As Long
End Type
Public Type TOKEN_GROUPS
   GroupCount   As Long
   Groups(500)  As SID_AND_ATTRIBUTES
End Type
' D�claration des constantes
Public Const TOKEN_ASSIGN_PRIMARY = &H1
Public Const TOKEN_DUPLICATE = &H2
Public Const TOKEN_IMPERSONATE = &H4
Public Const TOKEN_QUERY = &H8
Public Const TOKEN_QUERY_SOURCE = &H10
Public Const TOKEN_ADJUST_PRIVILEGES = &H20
Public Const TOKEN_ADJUST_GROUPS = &H40
Public Const TOKEN_ADJUST_DEFAULT = &H80
Public Const TOKEN_ALL_ACCESS = TOKEN_ASSIGN_PRIMARY + TOKEN_DUPLICATE + TOKEN_IMPERSONATE + TOKEN_QUERY + TOKEN_QUERY_SOURCE + TOKEN_ADJUST_PRIVILEGES + TOKEN_ADJUST_GROUPS + TOKEN_ADJUST_DEFAULT
Public Const SE_DEBUG_NAME As String = "SeDebugPrivilege"
Public Const SE_PRIVILEGE_ENABLED = &H2
Public Const TOKEN_USER     As Long = 1
Public Const TOKEN_GROUPS   As Long = 2
