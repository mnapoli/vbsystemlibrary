Attribute VB_Name = "modAPI"
'---------------------------------------------------------------------------------------
' Module    : modAPI
' DateTime  : 22/11/2006 23:02
' Author    : Vb System Library
' Purpose   : Regroupe toutes les d�clarations d'API, de constantes et de types
'---------------------------------------------------------------------------------------

Option Explicit



'---------------------------------------------------------------------------------------
' Divers
Public Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long
Public Const MAX_PATH As Integer = 260
Public Declare Function GetSecurityInfo Lib "advapi32.dll" (ByVal hObject As Long, ByVal ObjectType As Long, ByVal SecurityInformation As Long, ppsidOwner As Long, ppsidGroup As Long, ppDacl As Long, ppSacl As Long, ppSecurityDescriptor As Long) As Long
Public Declare Function LookupAccountSid Lib "advapi32.dll" Alias "LookupAccountSidA" (ByVal lpSystemName As String, ByVal Sid As Long, ByVal name As String, cbName As Long, ByVal ReferencedDomainName As String, cbReferencedDomainName As Long, peUse As Long) As Long
Public Const SE_KERNEL_OBJECT As Long = 6
Public Const OWNER_SECURITY_INFORMATION As Long = 1
Public Const GROUP_SECURITY_INFORMATION As Long = 2
' Pour lister les process, modules, threads
Public Declare Function CreateToolhelp32Snapshot Lib "kernel32.dll" (ByVal dwFlags As Long, ByVal th32ProcessID As Long) As Long


'---------------------------------------------------------------------------------------
' Processus
' Permet d'obtenir un handle d'un processus particulier
Public Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInheritHandle As Long, ByVal dwProcessId As Long) As Long
'//Constantes d'acc�s aux processus
Public Const PROCESS_QUERY_INFORMATION = 1024
Public Const PROCESS_VM_READ = 16
Public Const PROCESS_TERMINATE = &H1
Public Const PROCESS_READ_CONTROL As Long = &H20000
Public Declare Function TerminateProcess Lib "kernel32" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long
Public Declare Function GetExitCodeProcess Lib "kernel32" (ByVal hProcess As Long, lpExitCode As Long) As Long
Public Const STILL_ACTIVE = &H103
' Permet d'obtenir des infos sur les temps des processus
Public Declare Function GetProcessTimes Lib "kernel32" (ByVal hProcess As Long, lpCreationTime As Currency, lpExitTime As Currency, lpKernelTime As Currency, lpUserTime As Currency) As Long
' Renvoie le process courant
Public Declare Function GetCurrentProcess Lib "kernel32.dll" () As Long
' Enum�re les modules d'un processus
Public Declare Function EnumProcessModules Lib "PSAPI.DLL" (ByVal hProcess As Long, ByRef lphModule As Long, ByVal cb As Long, ByRef lpcbNeeded As Long) As Long
' D�finir la priorit� du processus
Public Declare Function SetPriorityClass Lib "kernel32" (ByVal hProcess As Long, ByVal dwPriorityClass As Long) As Long
' Constantes des priorit�s (6 niveaux de priorit�s)
Public Const IDLE_PRIORITY_CLASS As Long = &H40 ' minimum
Public Const BELOW_NORMAL_PRIORITY_CLASS As Long = &H4000 ' normal -
Public Const NORMAL_PRIORITY_CLASS As Long = &H20 ' normal
Public Const ABOVE_NORMAL_PRIORITY_CLASS As Long = &H8000 ' normal +
Public Const HIGH_PRIORITY_CLASS As Long = &H80 ' haute
Public Const REALTIME_PRIORITY_CLASS As Long = &H100 ' maximum
' Pour la taille d'un processus
Public Declare Function GetProcessMemoryInfo Lib "PSAPI.DLL" (ByVal hProcess As Long, ppsmemCounters As PROCESS_MEMORY_COUNTERS, ByVal cb As Long) As Long
Public Type PROCESS_MEMORY_COUNTERS
    cb As Long                          ' Taille de la structure
    PageFaultCount As Long              ' Nombre d'erreurs de page
    PeakWorkingSetSize As Long          ' Utilisation max de la m�moire RAM
    WorkingSetSize As Long              ' Utilisation de la m�moire RAM
    QuotaPeakPagedPoolUsage As Long     ' Utilisation max de la m�moire pagin�e
    QuotaPagedPoolUsage As Long         ' Utilisation de la m�moire pagin�e
    QuotaPeakNonPagedPoolUsage As Long
    QuotaNonPagedPoolUsage As Long
    PagefileUsage As Long               ' Utilisation de la m�moire virtuelle
    PeakPagefileUsage As Long           ' Utilisation max de la m�moire virtuelle
End Type


'---------------------------------------------------------------------------------------
' Fenetres
Public Declare Function GetWindow Lib "user32" (ByVal hWnd As Long, ByVal wCmd As Long) As Long
Public Const GW_CHILD = 5
Public Const GW_HWNDNEXT = 2
Public Declare Function GetDesktopWindow Lib "user32" () As Long


'---------------------------------------------------------------------------------------
' Modules
Public Declare Function GetModuleFileNameEx Lib "PSAPI.DLL" Alias "GetModuleFileNameExA" (ByVal hProcess As Long, ByVal hModule As Long, ByVal lpFilename As String, ByVal nSize As Long) As Long


'---------------------------------------------------------------------------------------
' Threads
Public Declare Function Thread32First Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Declare Function Thread32Next Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Const TH32CS_SNAPTHREAD As Long = &H4&
' Pour ouvrir un thread
Public Declare Function OpenThread Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInherit As Long, ByVal dwThreadId As Long) As Long
Public Const THREAD_ALL_ACCESS = &H1F03FF
' Suspendre un thread
Public Declare Function SuspendThread Lib "kernel32" (ByVal hThread As Long) As Long
Public Declare Function ResumeThread Lib "kernel32" (ByVal hThread As Long) As Long
' Le type thread
Public Type THREADENTRY32
    dwSize As Long              'taille de cette structure (� initialiser avant l'appel � Thread32First ou Thread32Next)
    cntUsage As Long            'nombre de r�f�rence au thread
    th32ThreadID As Long        'ID du thread
    th32OwnerProcessID As Long  'ID du processus qui a cr�� le thread
    tpBasePri As Long           'priorit� initiale
    tpDeltaPri As Long          'priorit� actuelle
    dwFlags As Long             'rien de d�fini
End Type


'---------------------------------------------------------------------------------------
' Token Privileges
' R�cup�re et change les privil�ges
Public Declare Function AdjustTokenPrivileges Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal DisableAllPrivileges As Long, NewState As TOKEN_PRIVILEGES, ByVal BufferLength As Long, PreviousState As TOKEN_PRIVILEGES, ReturnLength As Long) As Long
Public Declare Function OpenProcessToken Lib "advapi32.dll" (ByVal ProcessHandle As Long, ByVal DesiredAccess As Long, TokenHandle As Long) As Long
Public Declare Function LookupPrivilegeValue Lib "advapi32.dll" Alias "LookupPrivilegeValueA" (ByVal lpSystemName As String, ByVal lpName As String, lpLuid As LUID) As Long
Public Declare Function GetTokenInformation Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal TokenInformationClass As Long, TokenInformation As Any, ByVal TokenInformationLength As Long, ReturnLength As Long) As Long
' D�claratios des Types
Public Type LUID
    LowPart As Long
    HighPart As Long
End Type
Public Type LUID_AND_ATTRIBUTES
    pLuid As LUID
    Attributes As Long
End Type
Public Type TOKEN_PRIVILEGES
    PrivilegeCount As Long
    TheLuid As LUID
    Attributes As Long
End Type
Public Type SID_IDENTIFIER_AUTHORITY
   Value(6) As Byte
End Type
Public Type SID_AND_ATTRIBUTES
   Sid          As Long
   Attributes   As Long
End Type
Public Type TOKEN_GROUPS
   GroupCount   As Long
   Groups(500)  As SID_AND_ATTRIBUTES
End Type
' D�claration des constantes
Public Const TOKEN_ASSIGN_PRIMARY = &H1
Public Const TOKEN_DUPLICATE = &H2
Public Const TOKEN_IMPERSONATE = &H4
Public Const TOKEN_QUERY = &H8
Public Const TOKEN_QUERY_SOURCE = &H10
Public Const TOKEN_ADJUST_PRIVILEGES = &H20
Public Const TOKEN_ADJUST_GROUPS = &H40
Public Const TOKEN_ADJUST_DEFAULT = &H80
Public Const TOKEN_ALL_ACCESS = TOKEN_ASSIGN_PRIMARY + TOKEN_DUPLICATE + TOKEN_IMPERSONATE + TOKEN_QUERY + TOKEN_QUERY_SOURCE + TOKEN_ADJUST_PRIVILEGES + TOKEN_ADJUST_GROUPS + TOKEN_ADJUST_DEFAULT
Public Const SE_DEBUG_NAME As String = "SeDebugPrivilege"
Public Const SE_PRIVILEGE_ENABLED = &H2
Public Const TOKEN_USER     As Long = 1
Public Const TOKEN_GROUPS   As Long = 2
