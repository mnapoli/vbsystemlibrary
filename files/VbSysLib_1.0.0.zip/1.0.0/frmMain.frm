VERSION 5.00
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   Caption         =   "Exemple d'utilisation de Vb System Library"
   ClientHeight    =   5175
   ClientLeft      =   60
   ClientTop       =   375
   ClientWidth     =   9255
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   ScaleHeight     =   5175
   ScaleWidth      =   9255
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtInfos 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4935
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Text            =   "frmMain.frx":ED42
      Top             =   120
      Width           =   9015
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()

    Dim sInfos As String
    Dim TabID() As Long
    
    GetAllPrivileges
    sInfos = "Tous les privileges obtenus" & vbCrLf
    
    sInfos = sInfos & "Fichier du processus n�4 : " & GetProcessFileName(4) & vbCrLf
    
    sInfos = sInfos & "Utilisation m�moire du processus n�4 : " & (GetProcessMemorySize(4) / 1024) & " Ko" & vbCrLf
    
    sInfos = sInfos & "Processus n�4 lanc� par : " & GetProcessUserName(4) & vbCrLf
    
    ListWindows TabID
    sInfos = sInfos & UBound(TabID) - LBound(TabID) & " Fen�tres ouvertes actuellement" & vbCrLf
    
    ListThreads TabID
    sInfos = sInfos & UBound(TabID) - LBound(TabID) & " Threads lanc�s actuellement" & vbCrLf
    
    txtInfos.Text = sInfos
    
End Sub
