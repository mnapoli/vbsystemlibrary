Attribute VB_Name = "modNTQuerySystemInformation"
'---------------------------------------------------------------------------------------
' Module    : modNTQuerySystemInformation
' DateTime  : 01/12/2006 20:02
' Author    : Vb System Library
' Purpose   : Contient les d�clarations de types n�cessaires aux appels �
'               NTQuerySystemInformation
'---------------------------------------------------------------------------------------

Option Explicit

Public Type UNICODE_STRING
    Length As Integer
    MaximumLength As Integer
    Buffer As Long
End Type

Public Type RTL_DRIVE_LETTER_CURDIR
    Flags As Integer
    Length As Integer
    TimeStamp As Long
    DosPath As UNICODE_STRING
End Type

Public Type PROCESS_PARAMETERS
    AllocationSize As Long
    Size As Long
    Flags As Long
    Zero As Long
    Console As Long
    ProcessGroup As Long
    StdInput As Long
    StdOutput As Long
    StdError As Long
    CurrentDirectoryName As UNICODE_STRING
    CurrentDirectoryHandle As Long
    DllPath As UNICODE_STRING
    ImageFile As UNICODE_STRING
    CommandLine As UNICODE_STRING
    Environment As Long
    X As Long
    Y As Long
    XSize As Long
    YSize As Long
    XCountChars As Long
    YCountChars As Long
    FillAttribute As Long
    Flags2 As Long
    ShowWindow As Long
    WindowTitle As UNICODE_STRING
    Desktop As UNICODE_STRING
    ShellInfo As UNICODE_STRING
    RuntimeData As UNICODE_STRING
    DLCurrentDirectory(31) As RTL_DRIVE_LETTER_CURDIR
End Type

' Informations brutes sur le PEB
Public Type peb
    InheritedAddressSpace As Byte
    ReadImageFileExecOptions As Byte
    BeingDebugged As Byte
    Reserved1 As Byte
    Mutant As Long 'new
    SectionBaseAddress As Long
    ProcessModuleInfo As Long
    ProcessParameters As Long
    SubSystemData As Long
    ProcessHeap As Long
    FastPebLock As Long
    AcquireFastPebLock As Long
    ReleaseFastPebLock As Long
    EnvironmentUpdateCount As Long 'new
    User32Dispatch As Long
    EventLogSection As Long 'new
    EventLog As Long 'new
    ExecuteOptions As Long 'new
    'FreeList As Long ' // PEB_FREE_BLOCK 'new
    TlsBitMapSize As Long
    TlsBitMap As Long
    TlsBitMapData(1 To 2) As Long
    ReadOnlySharedMemoryBase As Long
    ReadOnlySharedMemoryHeap As Long
    ReadOnlyStaticServerData As Long
    InitAnsiCodePageData As Long
    InitOemCodePageData As Long
    InitUnicodeCaseTableData As Long
    KeNumberProcessors As Long
    NtGlobalFlag As Long
    Reserved9 As Long
    MmCriticalSectionTimeout As Currency
    MmHeapSegmentReserve As Long
    MmHeapSegmentCommit As Long
    MmHeapDeCommitTotalFreeThreshold As Long
    MmHeapDeCommitFreeBlockThreshold As Long
    NumberOfHeaps As Long
    AvailableHeaps As Long
    ProcessHeapsListBuffer As Long
    GdiSharedHandleTable As Long 'new
    ProcessStarterHelper As Long 'new
    GdiInitialBatchLimit As Long 'new
    LoaderLock As Long
    NtMajorVersion As Long
    NtMinorVersion As Long
    NtBuildNumber As Integer
    NtCSDVersion As Integer
    PlatformId As Long
    Subsystem As Long
    MajorSubsystemVersion As Long
    MinorSubsystemVersion As Long
    AffinityMask As Long
    GdiHandleBuffer(33) As Long 'new
    PostProcessInitRoutine As Long 'new
    TlsExpansionBitmap As Long 'new
    TlsExpansionBitmapBits(127) As Byte 'new
    SessionId As Long 'new
    AppCompatFlags(1 To 2) As Long 'new
    AppCompatFlagsUser(1 To 2) As Long 'new
    ShimData As Long 'new
    AppCompatInfo As Long 'new
    CSDVersion As UNICODE_STRING 'new
    ActivationContextData As Long 'new
    ProcessAssemblyStorageMap As Long 'new
    SystemDefaultActivationData As Long 'new
    SystemAssemblyStorageMap As Long 'new
    MinimumStackCommit As Long 'new
    FlsCallBack As Long 'new
    FlsListHead As Long 'new
    FlsBitmap As Long 'new
    FlsBitmapBits(3) As Long 'new
    FlsHighIndex As Long 'new
End Type

Public Type VM_COUNTERS
    PeakVirtualSize As Long
    VirtualSize As Long
    PageFaultCount As Long
    PeakWorkingSetSize As Long
    WorkingSetSize As Long
    QuotaPeakPagedPoolUsage As Long
    QuotaPagedPoolUsage As Long
    QuotaPeakNonPagedPoolUsage As Long
    QuotaNonPagedPoolUsage As Long
    PagefileUsage As Long
    PeakPagefileUsage As Long
End Type

Public Type IO_COUNTERS
    ReadOperationCount As Currency
    WriteOperationCount As Currency
    OtherOperationCount As Currency
    ReadTransferCount As Currency
    WriteTransferCount As Currency
    OtherTransferCount As Currency
End Type

' ID client
Public Type CLIENT_ID
    UniqueProcess As Long
    UniqueThread As Long
End Type

Public Type PROCESS_BASIC_INFORMATION ' Information Class 0
    ExitStatus As Long
    PEBBaseAddress As Long
    AffinityMask As Long
    BasePriority As Long
    UniqueProcessId As Long
    InheritedFromUniqueProcessId As Long
End Type


' Infos sur un thread
Public Type SYSTEM_THREADS
    KernelTime As Currency
    UserTime As Currency
    CreateTime As Currency
    WaitTime As Long
    StartAddress As Long
    ClientId As CLIENT_ID
    Priority As Long
    BasePriority As Long
    ContextSwitchCount As Long
    State As Long
    WaitReason As Long
End Type

' Infos sur un processus
Public Type SYSTEM_PROCESSES ' Information Class 5
    NextEntryDelta As Long
    ThreadCount As Long
    Reserved1 As Long
    Reserved2 As Long
    Reserved3 As Long
    Reserved4 As Long
    Reserved5 As Long
    Reserved6 As Long
    CreateTime As Currency
    UserTime As Currency
    KernelTime As Currency
    ProcessName As UNICODE_STRING
    BasePriority As Long
    ProcessID As Long
    InheritedFromProcessId As Long
    HandleCount As Long
    Reserved7 As Long
    Reserved8 As Long
    VmCounters As VM_COUNTERS
    IoCounters As IO_COUNTERS ' Windows 2000 only
    Threads() As SYSTEM_THREADS
End Type
