VERSION 5.00
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Exemple d'utilisation de Vb System Library"
   ClientHeight    =   5175
   ClientLeft      =   45
   ClientTop       =   360
   ClientWidth     =   9255
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5175
   ScaleWidth      =   9255
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdMove 
      Caption         =   "D�placer"
      Height          =   495
      Left            =   6120
      TabIndex        =   2
      Top             =   4560
      Width           =   1695
   End
   Begin VB.CommandButton cmdRefresh 
      Caption         =   "Actualiser"
      Height          =   495
      Left            =   3720
      TabIndex        =   1
      Top             =   4560
      Width           =   1815
   End
   Begin VB.TextBox txtInfos 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4335
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Text            =   "frmMain.frx":ED42
      Top             =   120
      Width           =   9015
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'-> API retourne la valeur du compteur Haut�Performance, s'il existe
Private Declare Function QueryPerformanceCounter Lib "kernel32" _
            (lpPerformanceCount As Currency) As Long
'-> API retourne la fr�quence du compteur Haut�Performance, s'il existe
Private Declare Function QueryPerformanceFrequency Lib "kernel32" _
            (lpFrequency As Currency) As Long

Dim TimeStart   As Currency     ' tps au d�marrage du compteur
Dim TimeStop    As Currency     ' tps � l'arr�t du compteur
Dim Frequency   As Currency     ' fr�quence du compteur
Dim TimeFinal   As Single

Dim currentWindow As New Window

Private Sub cmdMove_Click()
    currentWindow.Left = Rnd() * 100
    currentWindow.Top = Rnd() * 100
End Sub

Private Sub cmdRefresh_Click()

    Dim LstProc As New ListProcesses
    Dim Proc4 As New Process
    Dim LstWin As New ListWindows

    Dim sInfos As String
    Dim TabID() As Long
    Dim T As Long
    
    GetAllPrivileges
    sInfos = "Tous les privileges obtenus" & vbCrLf
    
    sInfos = sInfos & "Fichier du processus n�4 : " & GetProcessFileName(4) & vbCrLf
    
    sInfos = sInfos & "Utilisation m�moire du processus n�4 : " & (GetProcessMemoryUsage(4) / 1024) & " Ko" & vbCrLf
    
    sInfos = sInfos & "Processus n�4 lanc� par : " & GetProcessUserName(4) & vbCrLf & vbCrLf
    
    Proc4.ID = 4
    Proc4.RefreshInfos
    sInfos = sInfos & "Processus n�4 : " & Proc4.Name & vbCrLf
    sInfos = sInfos & "Priorit� du processus n�4 : " & Proc4.Priority & vbCrLf
    sInfos = sInfos & "Processus n�4 lanc� par : " & Proc4.UserName & vbCrLf & vbCrLf
    
    ListWindows TabID
    sInfos = sInfos & UBound(TabID) - LBound(TabID) & " Fen�tres ouvertes actuellement" & vbCrLf
    
    ListThreads TabID
    sInfos = sInfos & UBound(TabID) - LBound(TabID) & " Threads lanc�s actuellement" & vbCrLf & vbCrLf
    
    ' Rafraichit la liste des processus
    QueryPerformanceFrequency Frequency
    QueryPerformanceCounter TimeStart
    
    LstProc.RefreshList
    sInfos = sInfos & "Listage des processus effectu�" & vbCrLf
    sInfos = sInfos & LstProc.Count & " processus lanc�s actuellement" & vbCrLf & vbCrLf
    
    ' Parcourt la liste des processus
    For T = 1 To LstProc.Count
        sInfos = sInfos & LstProc.Process(T).ID & " - " & LstProc.Process(T).Name & vbCrLf
    Next
    
    ' Les fenetres
    LstWin.RefreshList
    sInfos = sInfos & vbCrLf & vbCrLf & "Listage des fenetres effectu�" & vbCrLf
    sInfos = sInfos & LstWin.Count & " fenetres ouvertes actuellement" & vbCrLf & vbCrLf
    For T = 1 To LstWin.Count
        sInfos = sInfos & LstWin.Window(T).Handle & " - " & LstWin.Window(T).Caption & vbCrLf
    Next
    
    QueryPerformanceCounter TimeStop
    TimeFinal = TimeStop - TimeStart
    frmMain.Caption = Str(TimeFinal) + " ms"
    
    txtInfos.Text = sInfos
    
End Sub

Private Sub Form_Load()
    currentWindow.Handle = Me.hWnd
    EnableWindowTransparency Me.hWnd
    ChangeWindowTransparency Me.hWnd, 220
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Set currentWindow = Nothing
End Sub
