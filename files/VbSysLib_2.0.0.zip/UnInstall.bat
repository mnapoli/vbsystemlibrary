@Echo Off

RegSvr32 -u VbSysLib.dll