Attribute VB_Name = "modCallBack"
'---------------------------------------------------------------------------------------
' Module    : modCallBack
' DateTime  : 30/04/2007 23:28
' Author    : Vb System Library
' Purpose   : Module utilis� pour placer les fonctions de CallBack des API
' Copyright : (C) 2007 L'�quipe Vb System Library
'              See "modPresentation" for more information
'---------------------------------------------------------------------------------------
' Librairie de fonctions permettant d'agir simplement et rapidement sur le syst�me.
' Copyright (C) 2007 - L'�quipe Vb System Library
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.
' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
'---------------------------------------------------------------------------------------


Option Explicit

Private localVScreen As VirtualScreen

' Cette fonction est appel�e par EnumDisplayMonitors pour �num�rer les �crans
Private Function MonitorEnumProc(ByVal hMonitor As Long, ByVal hDCMonitor As Long, ByVal lprcMonitor As Long, ByVal dwData As Long) As Long
   localVScreen.Add hMonitor
   MonitorEnumProc = 1
End Function

' Enum�re les �crans
Public Sub RefreshListMonitor(VirtualScreen As VirtualScreen)
    ' On est oblig� de placer MonitorEnumProc dans un module pour pouvoir faire AddressOf
    Set localVScreen = VirtualScreen
    localVScreen.Clear
    EnumDisplayMonitors 0, ByVal 0&, AddressOf MonitorEnumProc, 0
End Sub
