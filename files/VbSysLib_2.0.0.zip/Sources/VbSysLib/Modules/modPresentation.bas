Attribute VB_Name = "modPresentation"
Option Explicit

'     _    _     _ ___ __           _  _  _  _    http://vbsystemlibrary.free.fr/
' \ /|_)  (_ \ /(_  | |_ |\/|  |  ||_)|_)|_||_)\ /
'  v |_)   _) |  _) | |__|  |  |__||_)| \| || \ |



'   Vb System Library
' Librairie de fonctions permettant d'agir simplement et rapidement sur le syst�me.
' Copyright (C) 2007 - L'�quipe Vb System Library
'
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
'
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

' If you want to contact us, you can visit :
' http://vbsystemlibrary.free.fr/
' or send a mail at vbsystemlibrary@free.fr
