Attribute VB_Name = "modTypes"
'---------------------------------------------------------------------------------------
' Module    : modTypes
' DateTime  : 30/04/2007 23:28
' Author    : Vb System Library
' Purpose   : Regroupe les structures publiques
' Copyright : (C) 2007 L'�quipe Vb System Library
'              See "modPresentation" for more information
'---------------------------------------------------------------------------------------
' Librairie de fonctions permettant d'agir simplement et rapidement sur le syst�me.
' Copyright (C) 2007 - L'�quipe Vb System Library
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.
' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
'---------------------------------------------------------------------------------------


Option Explicit

'---------------------------------------------------------------------------------------
' Divers

Public Type POINTAPI
    x As Long
    y As Long
End Type

' Descripteur de tableau
Public Type SafeArray1d
    cDims       As Integer 'nombre de dimensions
    fFeatures   As Integer 'falgs
    cbElements  As Long    'taille des elements
    cLocks      As Long    'tableau non redimensionnable
    pvData      As Long    'pointeur vers les donn�es du tableau
    cElements   As Long    'nombre d'elements
    lLbound     As Long    'limite basse
End Type

' Informations sur une plage m�moire
Public Type MEMORY_BASIC_INFORMATION ' 28 bytes
    BaseAddress         As Long     ' Adresse de la plage m�moire
    AllocationBase      As Long
    AllocationProtect   As Long
    RegionSize          As Long     ' Taille en octets de la plage m�moire
    State               As Long
    Protect             As Long     ' Protection d'acc�s � la plage m�moire
    lType               As Long
End Type

Public Type SYSTEM_INFO ' 36 Bytes
    dwOemID                     As Long     ' Obsolete
    dwPageSize                  As Long
    lpMinimumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus petite accessible aux applications et DLL
    lpMaximumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus grande accessible aux applications et DLL
    dwActiveProcessorMask       As Long
    dwNumberOrfProcessors       As Long     ' Nombre de processeurs dans le systeme
    dwProcessorType             As Long
    dwAllocationGranularity     As Long
    wProcessorLevel             As Integer
    wProcessorRevision          As Integer
End Type



Public Type WINDOWPLACEMENT
    Length              As Long
    Flags               As Long
    ShowCmd             As Long
    ptMinPosition       As POINTAPI
    ptMaxPosition       As POINTAPI
    rcNormalPosition    As RECT
End Type

' Modules
Public Type MODULEINFO
    lpBaseOfDll As Long
    SizeOfImage As Long
    EntryPoint  As Long
End Type

' Le type thread
Public Type THREADENTRY32
    dwSize              As Long  'taille de cette structure (� initialiser avant l'appel � Thread32First ou Thread32Next)
    cntUsage            As Long  'nombre de r�f�rence au thread
    th32ThreadID        As Long  'ID du thread
    th32OwnerProcessID  As Long  'ID du processus qui a cr�� le thread
    tpBasePri           As Long  'priorit� initiale
    tpDeltaPri          As Long  'priorit� actuelle
    dwFlags             As Long  'rien de d�fini
End Type

Public Type VS_FIXEDFILEINFO
    dwSignature         As Long
    dwStrucVersion      As Long
    dwFileVersionMS     As Long
    dwFileVersionLS     As Long
    dwProductVersionMS  As Long
    dwProductVersionLS  As Long
    dwFileFlagsMask     As Long
    dwFileFlags         As Long
    dwFileOS            As Long
    dwFileType          As Long
    dwFileSubtype       As Long
    dwFileDateMS        As Long
    dwFileDateLS        As Long
End Type

' Un argument de type Enum permet l'apparition d'une liste de
' choix lors de la saisie de l'appel de fonction.
Public Enum mfFileInfo
    fileinfoCompanyName = 0
    fileinfoFileDescription = 1
    fileinfoFileVersion = 2
    fileinfoInternalName = 3
    fileinfoLegalCopyright = 4
    fileinfoOriginalFileName = 5
    fileinfoProductName = 6
    fileinfoProductVersion = 7
End Enum

Public Type SHITEMID
    cb      As Long
    abID    As Byte
End Type

Public Type ITEMIDLIST
    mkid    As SHITEMID
End Type

Public Type SHFILEINFO
    hIcon           As Long
    iIcon           As Long
    dwAttributes    As Long
    szDisplayName   As String * MAX_PATH
    szTypeName      As String * 80
End Type


'---------------------------------------------------------------------------------------
' Graphismes

Public Type GUID
    Data1           As Long
    Data2           As Integer
    Data3           As Integer
    Data4(0 To 7)   As Byte
End Type

' Structure contenant des infos sur une image
' Normalement cette structure contient une union mais VB ne les g�re pas
Public Type PICTDESC
    cbSizeofStruct  As Long  ' Taille de cette structure
    picType         As Long  ' Type d'image : ICON, BITMAP, METAFILE, ENHMETAFILE
    ' D�but union
    hImage          As Long  ' Handle de l'image
    xExt            As Long  ' Taille x de l'image pour une METAFILE
    yExt            As Long  ' Taille y de l'image pour une METAFILE
End Type


Public Type OSVERSIONINFO
    dwOSVersionInfoSize     As Long
    dwMajorVersion          As Long
    dwMinorVersion          As Long
    dwBuildNumber           As Long
    dwPlatformId            As Long
    szCSDVersion            As String * 128
End Type


'---------------------------------------------------------------------------------------
' Token Privileges

Public Type LUID
    LowPart         As Long
    HighPart        As Long
End Type

Public Type LUID_AND_ATTRIBUTES
    pLuid           As LUID
    Attributes      As Long
End Type

Public Type TOKEN_PRIVILEGES
    PrivilegeCount  As Long
    Privileges      As LUID_AND_ATTRIBUTES
End Type

Public Type SID_AND_ATTRIBUTES
    Sid             As Long
    Attributes      As Long
End Type

Public Type TOKEN_GROUPS
    GroupCount      As Long
    Groups(500)     As SID_AND_ATTRIBUTES
End Type



Public Type UNICODE_STRING
    Length          As Integer
    MaximumLength   As Integer
    Buffer          As Long
End Type

Public Type RTL_DRIVE_LETTER_CURDIR
    Flags       As Integer
    Length      As Integer
    TimeStamp   As Long
    DosPath     As UNICODE_STRING
End Type

Public Type PROCESS_PARAMETERS
    AllocationSize              As Long
    Size                        As Long
    Flags                       As Long
    Zero                        As Long
    Console                     As Long
    ProcessGroup                As Long
    StdInput                    As Long
    StdOutput                   As Long
    StdError                    As Long
    CurrentDirectoryName        As UNICODE_STRING
    CurrentDirectoryHandle      As Long
    DllPath                     As UNICODE_STRING
    ImageFile                   As UNICODE_STRING
    CommandLine                 As UNICODE_STRING
    Environment                 As Long
    x                           As Long
    y                           As Long
    XSize                       As Long
    YSize                       As Long
    XCountChars                 As Long
    YCountChars                 As Long
    FillAttribute               As Long
    Flags2                      As Long
    ShowWindow                  As Long
    WindowTitle                 As UNICODE_STRING
    Desktop                     As UNICODE_STRING
    ShellInfo                   As UNICODE_STRING
    RuntimeData                 As UNICODE_STRING
    DLCurrentDirectory(31)      As RTL_DRIVE_LETTER_CURDIR
End Type

' Informations brutes sur le PEB
Public Type peb
    InheritedAddressSpace               As Byte
    ReadImageFileExecOptions            As Byte
    BeingDebugged                       As Byte
    Reserved1                           As Byte
    Mutant                              As Long 'new
    SectionBaseAddress                  As Long
    ProcessModuleInfo                   As Long
    ProcessParameters                   As Long
    SubSystemData                       As Long
    ProcessHeap                         As Long
    FastPebLock                         As Long
    AcquireFastPebLock                  As Long
    ReleaseFastPebLock                  As Long
    EnvironmentUpdateCount              As Long 'new
    User32Dispatch                      As Long
    EventLogSection                     As Long 'new
    EventLog                            As Long 'new
    ExecuteOptions                      As Long 'new
    'FreeList As Long ' // PEB_FREE_BLOCK 'new
    TlsBitMapSize                       As Long
    TlsBitMap                           As Long
    TlsBitMapData(1 To 2)               As Long
    ReadOnlySharedMemoryBase            As Long
    ReadOnlySharedMemoryHeap            As Long
    ReadOnlyStaticServerData            As Long
    InitAnsiCodePageData                As Long
    InitOemCodePageData                 As Long
    InitUnicodeCaseTableData            As Long
    KeNumberProcessors                  As Long
    NtGlobalFlag                        As Long
    Reserved9                           As Long
    MmCriticalSectionTimeout            As Currency
    MmHeapSegmentReserve                As Long
    MmHeapSegmentCommit                 As Long
    MmHeapDeCommitTotalFreeThreshold    As Long
    MmHeapDeCommitFreeBlockThreshold    As Long
    NumberOfHeaps                       As Long
    AvailableHeaps                      As Long
    ProcessHeapsListBuffer              As Long
    GdiSharedHandleTable                As Long 'new
    ProcessStarterHelper                As Long 'new
    GdiInitialBatchLimit                As Long 'new
    LoaderLock                          As Long
    NtMajorVersion                      As Long
    NtMinorVersion                      As Long
    NtBuildNumber                       As Integer
    NtCSDVersion                        As Integer
    PlatformId                          As Long
    Subsystem                           As Long
    MajorSubsystemVersion               As Long
    MinorSubsystemVersion               As Long
    AffinityMask                        As Long
    GdiHandleBuffer(33)                 As Long 'new
    PostProcessInitRoutine              As Long 'new
    TlsExpansionBitmap                  As Long 'new
    TlsExpansionBitmapBits(127)         As Byte 'new
    SessionId                           As Long 'new
    AppCompatFlags(1 To 2)              As Long 'new
    AppCompatFlagsUser(1 To 2)          As Long 'new
    ShimData                            As Long 'new
    AppCompatInfo                       As Long 'new
    CSDVersion                          As UNICODE_STRING 'new
    ActivationContextData               As Long 'new
    ProcessAssemblyStorageMap           As Long 'new
    SystemDefaultActivationData         As Long 'new
    SystemAssemblyStorageMap            As Long 'new
    MinimumStackCommit                  As Long 'new
    FlsCallBack                         As Long 'new
    FlsListHead                         As Long 'new
    FlsBitmap                           As Long 'new
    FlsBitmapBits(3)                    As Long 'new
    FlsHighIndex                        As Long 'new
End Type

Public Type VM_COUNTERS
    PeakVirtualSize             As Long
    VirtualSize                 As Long
    PageFaultCount              As Long
    PeakWorkingSetSize          As Long
    WorkingSetSize              As Long
    QuotaPeakPagedPoolUsage     As Long
    QuotaPagedPoolUsage         As Long
    QuotaPeakNonPagedPoolUsage  As Long
    QuotaNonPagedPoolUsage      As Long
    PagefileUsage               As Long
    PeakPagefileUsage           As Long
End Type

Public Type IO_COUNTERS
    ReadOperationCount      As Currency
    WriteOperationCount     As Currency
    OtherOperationCount     As Currency
    ReadTransferCount       As Currency
    WriteTransferCount      As Currency
    OtherTransferCount      As Currency
End Type

' ID client
Public Type CLIENT_ID
    UniqueProcess As Long
    UniqueThread As Long
End Type

Public Type PROCESS_BASIC_INFORMATION ' Information Class 0
    ExitStatus                      As Long
    PEBBaseAddress                  As Long
    AffinityMask                    As Long
    BasePriority                    As Long
    UniqueProcessId                 As Long
    InheritedFromUniqueProcessId    As Long
End Type

' Infos sur un thread
Public Type SYSTEM_THREADS
    KernelTime          As Currency
    UserTime            As Currency
    CreateTime          As Currency
    WaitTime            As Long
    StartAddress        As Long
    ClientId            As CLIENT_ID
    Priority            As Long
    BasePriority        As Long
    ContextSwitchCount  As Long
    State               As Long
    WaitReason          As Long
End Type

' Infos sur un processus
Public Type SYSTEM_PROCESSES ' Information Class 5
    NextEntryDelta          As Long
    ThreadCount             As Long
    Reserved1               As Long
    Reserved2               As Long
    Reserved3               As Long
    Reserved4               As Long
    Reserved5               As Long
    Reserved6               As Long
    CreateTime              As Currency
    UserTime                As Currency
    KernelTime              As Currency
    ProcessName             As UNICODE_STRING
    BasePriority            As Long
    ProcessID               As Long
    InheritedFromProcessId  As Long
    HandleCount             As Long
    Reserved7               As Long
    Reserved8               As Long
    VmCounters              As VM_COUNTERS
    IoCounters              As IO_COUNTERS ' Windows 2000 only
    Threads()               As SYSTEM_THREADS
End Type

Public Type THREAD_BASIC_INFORMATION
    ExitStatus      As Long
    TebBaseAddress  As Long
    ClientId        As CLIENT_ID
    AffinityMask    As Long
    Priority        As Long
    BasePriority    As Long
End Type


' Infos sur un ecran
Public Type MONITORINFOEXW
   cbSize As Long
   rcMonitor As RECT
   rcWork As RECT
   dwFlags As Long
   b(0 To CCHDEVICENAME * 2 - 1) As Byte
End Type


' Types pour les fichiers
Public Type SYSTEMTIME
    wYear As Integer
    wMonth As Integer
    wDayOfWeek As Integer
    wDay As Integer
    wHour As Integer
    wMinute As Integer
    wSecond As Integer
    wMilliseconds As Integer
End Type
Public Type BY_HANDLE_FILE_INFORMATION
    dwFileAttributes As Long
    ftCreationTime As FILETIME
    ftLastAccessTime As FILETIME
    ftLastWriteTime As FILETIME
    dwVolumeSerialNumber As Long
    nFileSizeHigh As Long
    nFileSizeLow As Long
    nNumberOfLinks As Long
    nFileIndexHigh As Long
    nFileIndexLow As Long
End Type
Public Type WIN32_FIND_DATA
    dwFileAttributes As Long
    ftCreationTime As FILETIME
    ftLastAccessTime As FILETIME
    ftLastWriteTime As FILETIME
    nFileSizeHigh As Long
    nFileSizeLow As Long
    dwReserved0 As Long
    dwReserved1 As Long
    cFileName As String * 260
    cAlternate As String * 14
End Type
Public Type SECURITY_ATTRIBUTES
    nLength As Long
    lpSecurityDescriptor As Long
    bInheritHandle As Long
End Type
Public Type BrowseInfo
    hwndOwner As Long
    pIDLRoot As Long
    pszDisplayName As String
    lpszTitle As String
    ulFlags As Long
    lpfnCallback As Long
    lParam As Long
    iImage As Long
End Type
Public Type SHELLEXECUTEINFO
    cbSize As Long
    fMask As Long
    hWnd As Long
    lpVerb As String
    lpFile As String
    lpParameters As String
    lpDirectory As String
    nShow As Long
    hInstApp As Long
    lpIDList As Long
    lpClass As String
    hkeyClass As Long
    dwHotKey As Long
    hIcon As Long
    hProcess As Long
End Type
Public Type Fichier    'utilis� pour envoyer vers la corbeille
     hWnd As Long
     wFunc As Long
     pFrom As String
     pTo As String
     fFlags As Integer
     fAnyOperationsAborted As Boolean
     hNameMappings As Long
     lpszProgressTitle As String
End Type
Public Type OPENFILENAME
    lStructSize As Long
    hwndOwner As Long
    hInstance As Long
    lpstrFilter As String
    lpstrCustomFilter As Long
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As String
    nMaxFile As Long
    lpstrFileTitle As String
    nMaxFileTitle As Long
    lpstrInitialDir As String
    lpstrTitle As String
    Flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As String
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As Long
End Type
Public Type DISK_GEOMETRY
   Cylinders         As Currency
   MediaType         As Long
   TracksPerCylinder As Long
   SectorsPerTrack   As Long
   BytesPerSector    As Long
End Type
Public Type OVERLAPPED
    ternal As Long
    ternalHigh As Long
    Offset As Long
    OffsetHigh As Long
    hEvent As Long
End Type
Public Type PARTITION_INFORMATION
  StartingOffset As Currency
  PartitionLength As Currency
  HiddenSectors As Long
  PartitionNumber As Currency
  PartitionType As PARTITION_TYPE
  BootIndicator As Byte
  RecognizedPartition As Byte
  RewritePartition As Byte
End Type
Public Type IDEREGS
    bFeaturesReg As Byte ' // Used for specifying SMART "commands".
    bSectorCountReg As Byte ' // IDE sector count register
    bSectorNumberReg As Byte ' // IDE sector number register
    bCylLowReg As Byte ' // IDE low order cylinder value
    bCylHighReg As Byte ' // IDE high order cylinder value
    bDriveHeadReg As Byte ' // IDE drive/head register
    bCommandReg As Byte ' // Actual IDE command.
    bReserved As Byte ' // reserved for future use. Must be zero.
End Type
Public Type SENDCMDINPARAMS
    cBufferSize As Long ' Buffer size in bytes
    irDriveRegs As IDEREGS ' Structure with drive register values.
    bDriveNumber As Byte ' Physical drive number to send command to(0,1,2,3).
    bReserved(2) As Byte ' Bytes reserved
    dwReserved(3) As Long ' DWORDS reserved
    bBuffer() As Byte ' Input buffer.
End Type
Public Type IDSECTOR
    wGenConfig As Integer
    wNumCyls As Integer
    wReserved As Integer
    wNumHeads As Integer
    wBytesPerTrack As Integer
    wBytesPerSector As Integer
    wSectorsPerTrack As Integer
    wVendorUnique(2) As Integer
    sSerialNumber(19) As Byte
    wBufferType As Integer
    wBufferSize As Integer
    wECCSize As Integer
    sFirmwareRev(7) As Byte
    sModelNumber(39) As Byte
    wMoreVendorUnique As Integer
    wDoubleWordIO As Integer
    wCapabilities As Integer
    wReserved1 As Integer
    wPIOTiming As Integer
    wDMATiming As Integer
    wBS As Integer
    wNumCurrentCyls As Integer
    wNumCurrentHeads As Integer
    wNumCurrentSectorsPerTrack As Integer
    ulCurrentSectorCapacity As Long
    wMultSectorStuff As Integer
    ulTotalAddressableSectors As Long
    wSingleWordDMA As Integer
    wMultiWordDMA As Integer
    bReserved(127) As Byte
End Type

