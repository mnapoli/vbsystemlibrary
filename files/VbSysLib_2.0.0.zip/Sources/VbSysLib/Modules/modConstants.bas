Attribute VB_Name = "modConstants"
'---------------------------------------------------------------------------------------
' Module    : modConstants
' DateTime  : 30/04/2007 23:28
' Author    : Vb System Library
' Purpose   : Regroupe les constantes
' Copyright : (C) 2007 L'�quipe Vb System Library
'              See "modPresentation" for more information
'---------------------------------------------------------------------------------------
' Librairie de fonctions permettant d'agir simplement et rapidement sur le syst�me.
' Copyright (C) 2007 - L'�quipe Vb System Library
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.
' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
'---------------------------------------------------------------------------------------

Option Explicit


'---------------------------------------------------------------------------------------
' Divers

Public Const MAX_PATH As Integer = 260

Public Const SE_KERNEL_OBJECT   As Long = 6

Public Const OWNER_SECURITY_INFORMATION As Long = 1
Public Const GROUP_SECURITY_INFORMATION As Long = 2

Public Const KRN_LOAD  As String = "LoadLibraryA"
Public Const KRN_FREE  As String = "FreeLibrary"
Public Const KRN_DLL   As String = "Kernel32"
Public Const GET_HMOD  As String = "GetModuleHandleA"

' Manipuler la m�moire
Public Const MEM_RELEASE = &H8000
Public Const MEM_FREE = &H10000
Public Const MEM_COMMIT = &H1000
Public Const MEM_PRIVATE = &H20000
Public Const PAGE_READWRITE = &H4

' Pour lister les process, modules, threads
Public Const TH32CS_SNAPMODULE As Long = &H8    'modules du processus


' Renvoie l'adresse du descripteur de tableau
' Constante pour descripteur de tableau
Public Const FADF_AUTO = 1
Public Const FADF_FIXEDSIZE = 16
Public Const FADF_STATIC = 2
Public Const NanoSec       As Long = 10000000

Public Const INVALID_HANDLE_VALUE          As Long = -1


Public Const FILE_INVALID_ATTRIBUTES As Long = &HFFFFFFFF
Public Const FILE_ATTRIBUTE_NORMAL As Long = &H80


'---------------------------------------------------------------------------------------
' Processus

' Constantes d'acc�s aux processus
Public Const PROCESS_TERMINATE                  As Long = &H1
Public Const PROCESS_CREATE_THREAD              As Long = &H2
Public Const PROCESS_SET_SESSIONID              As Long = &H4
Public Const PROCESS_VM_OPERATION               As Long = &H8
Public Const PROCESS_VM_READ                    As Long = &H10
Public Const PROCESS_VM_WRITE                   As Long = &H20
Public Const PROCESS_DUP_HANDLE                 As Long = &H40
Public Const PROCESS_CREATE_PROCESS             As Long = &H80
Public Const PROCESS_SET_QUOTA                  As Long = &H100
Public Const PROCESS_SET_INFORMATION            As Long = &H200
Public Const PROCESS_QUERY_INFORMATION          As Long = &H400
Public Const PROCESS_SUSPEND_RESUME             As Long = &H800
Public Const PROCESS_READ_CONTROL               As Long = &H20000
Public Const SYNCHRONIZE                        As Long = &H100000
Public Const STANDARD_RIGHTS_REQUIRED           As Long = &HF0000
Public Const PROCESS_ALL_ACCESS                 As Long = (STANDARD_RIGHTS_REQUIRED Or SYNCHRONIZE Or &HFFF)

'------------------------------------
Public Const WM_QUIT = &H12
Public Const STILL_ACTIVE = &H103

Public Const IDLE_PRIORITY_CLASS            As Long = &H40   ' Basse
Public Const BELOW_NORMAL_PRIORITY_CLASS    As Long = &H4000 ' Inf�rieure � la normale
Public Const NORMAL_PRIORITY_CLASS          As Long = &H20   ' Normale
Public Const ABOVE_NORMAL_PRIORITY_CLASS    As Long = &H8000 ' Sup�rieure � la normale
Public Const HIGH_PRIORITY_CLASS            As Long = &H80   ' Haute
Public Const REALTIME_PRIORITY_CLASS        As Long = &H100  ' Temps r�el

' Pour la taille d'un processus
Public Const STATUS_INFO_LENGTH_MISMATCH As Long = &HC0000004
Public Const STATUS_SUCCESS As Long = &H0&
Public Const SystemProcessesAndThreadsInformation As Long = 5&
Public Const ProcessSessionInformation As Long = 24&

Public Const SystemCacheInformation As Long = 21

'---------------------------------------------------------------------------------------
' Fenetres
Public Const GW_CHILD = 5
Public Const GW_HWNDNEXT = 2
Public Const GWL_HWNDPARENT As Long = -8
'renvoie les styles de la fen�tre
Public Const GWL_STYLE      As Long = -16
'renvoie les styles �tendus de la fen�tre
Public Const GWL_EXSTYLE    As Long = -20
' Pour la transparence
Public Const WS_EX_LAYERED = &H80000
Public Const LWA_COLORKEY = &H1
Public Const LWA_ALPHA = &H2

Public Const SWP_NOSIZE = &H1
Public Const SWP_NOMOVE = &H2
Public Const HWND_TOP = 0
Public Const HWND_TOPMOST = -1
Public Const HWND_NOTOPMOST = -2

Public Const SW_HIDE = 0
Public Const SW_SHOWNORMAL = 1
Public Const SW_SHOWMINIMIZED = 2
Public Const SW_SHOWMAXIMIZED = 3
Public Const SW_MAXIMIZE = 3
Public Const SW_SHOWNOACTIVATE = 4
Public Const SW_SHOW = 5
Public Const SW_MINIMIZE = 6
Public Const SW_SHOWNA = 8
Public Const SW_RESTORE = 9

Public Const WM_CLOSE = &H10

Public Const MF_BYPOSITION = &H400&
Public Const MF_REMOVE = &H1000&


'---------------------------------------------------------------------------------------
Public Const TH32CS_SNAPTHREAD As Long = &H4&

Public Const THREAD_ALL_ACCESS = &H1F03FF


Public Const GENERIC_READ            As Long = &H80000000
Public Const FILE_SHARE_READ         As Long = &H1
Public Const FILE_SHARE_WRITE        As Long = &H2
Public Const OPEN_EXISTING           As Long = 3

Public Const SHGFI_USEFILEATTRIBUTES    As Long = &H10
Public Const SHGFI_DISPLAYNAME          As Long = &H200
Public Const SHGFI_TYPENAME             As Long = &H400
Public Const SHGFI_SMALLICON            As Long = &H1
Public Const SHGFI_LARGEICON            As Long = &H0
Public Const SHGFI_ICON                 As Long = &H100
Public Const SHGFI_EXETYPE              As Long = &H2000
Public Const SHGFI_SYSICONINDEX         As Long = &H4000
Public Const SHGFI_SHELLICONSIZE        As Long = &H4
Public Const BASIC_SHGFI_FLAGS = SHGFI_TYPENAME Or SHGFI_SHELLICONSIZE Or SHGFI_SYSICONINDEX Or SHGFI_DISPLAYNAME Or SHGFI_EXETYPE

Public Const DI_MASK = &H1
Public Const DI_IMAGE = &H2
Public Const DI_NORMAL = DI_MASK Or DI_IMAGE


Public Const PICTYPE_ICON = 3
Public Const DJM_SMALLICON = &H6605


Public Const TOKEN_USER     As Long = 1
Public Const TOKEN_GROUPS   As Long = 2

Public Const TOKEN_QUERY                        As Long = &H8&
Public Const TOKEN_ADJUST_PRIVILEGES            As Long = &H20&
Public Const SE_PRIVILEGE_ENABLED               As Long = &H2
Public Const SE_PRIVILEGE_DISBALED              As Long = &H0
Public Const SE_PRIVILEGE_ENABLED_BY_DEFAULT    As Long = &H1
Public Const SE_PRIVILEGE_USED_FOR_ACCESS       As Long = &H80000000

' Les noms des privil�ges
Public Const SE_AUDIT_NAME                  As String = "SeAuditPrivilege"
Public Const SE_BACKUP_NAME                 As String = "SeBackupPrivilege"
Public Const SE_CHANGE_NOTIFY_NAME          As String = "SeChangeNotifyPrivilege"
Public Const SE_CREATE_PAGEFILE_NAME        As String = "SeCreatePagefilePrivilege"
Public Const SE_CREATE_PERMANENT_NAME       As String = "SeCreatePermanentPrivilege"
Public Const SE_CREATE_TOKEN_NAME           As String = "SeCreateTokenPrivilege"
Public Const SE_DEBUG_NAME                  As String = "SeDebugPrivilege"
Public Const SE_REMOTE_SHUTDOWN_NAME        As String = "SeRemoteShutdownPrivilege"
Public Const SE_PROF_SINGLE_PROCESS_NAME    As String = "SeProfileSingleProcessPrivilege"
Public Const SE_RESTORE_NAME                As String = "SeRestorePrivilege"
Public Const SE_SECURITY_NAME               As String = "SeSecurityPrivilege"
Public Const SE_SHUTDOWN_NAME               As String = "SeShutdownPrivilege"
Public Const SE_SYSTEM_ENVIRONMENT_NAME     As String = "SeSystemEnvironmentPrivilege"
Public Const SE_SYSTEM_PROFILE_NAME         As String = "SeSystemProfilePrivilege"
Public Const SE_SYSTEMTIME_NAME             As String = "SeSystemtimePrivilege"
Public Const SE_TAKE_OWNERSHIP_NAME         As String = "SeTakeOwnershipPrivilege"
Public Const SE_TCB_NAME                    As String = "SeTcbPrivilege"
Public Const SE_MANAGE_VOLUME_NAME          As String = "SeManageVolumePrivilege"
Public Const SE_INC_BASE_PRIORITY_NAME      As String = "SeIncreaseBasePriorityPrivilege"
Public Const SE_INCREASE_QUOTA_NAME         As String = "SeIncreaseQuotaPrivilege"
Public Const SE_LOCK_MEMORY_NAME            As String = "SeLockMemoryPrivilege"
Public Const SE_LOAD_DRIVER_NAME            As String = "SeLoadDriverPrivilege"
Public Const SE_MACHINE_ACCOUNT_NAME        As String = "SeMachineAccountPrivilege"

' Taille du nom d'un p�riph�rique
Public Const CCHDEVICENAME = 32

' Infos sur les �crans
Public Const MONITORINFOF_PRIMARY = &H1
Public Const SM_XVIRTUALSCREEN = 76
Public Const SM_YVIRTUALSCREEN = 77
Public Const SM_CXVIRTUALSCREEN = 78
Public Const SM_CYVIRTUALSCREEN = 79
Public Const SM_CMONITORS = 80
Public Const SM_SAMEDISPLAYFORMAT = 81



Public Const FO_COPY                       As Long = &H2&
Public Const FO_MOVE                       As Long = &H1&
Public Const FOF_ALLOWUNDO                 As Long = &H40
Public Const FOF_SIMPLEPROGRESS            As Long = &H100&
Public Const CREATE_ALWAYS                 As Long = 2
Public Const CREATE_NEW                    As Long = 1
Public Const GENERIC_WRITE                 As Long = &H40000000
Public Const BIF_RETURNONLYFSDIRS          As Long = 1
Public Const BIF_DONTGOBELOWDOMAIN         As Long = 2
Public Const IOCTL_DISK_GET_DRIVE_GEOMETRY As Long = &H70000
Public Const IOCTL_DISK_GET_PARTITION_INFO As Long = &H74004
Public Const IDENTIFY_BUFFER_SIZE          As Long = 512
Public Const OUTPUT_DATA_SIZE              As Long = IDENTIFY_BUFFER_SIZE + 16
Public Const DFP_RECEIVE_DRIVE_DATA        As Long = &H7C088
Public Const FILE_TYPE_CHAR                As Long = &H2
Public Const FILE_TYPE_DISK                As Long = &H1
Public Const FILE_TYPE_PIPE                As Long = &H3
Public Const FILE_TYPE_UNKNOWN             As Long = &H0
Public Const LBUFSIZE                      As Long = 5000000
Public Const FILE_FLAG_BACKUP_SEMANTICS    As Long = &H2000000
Public Const FILE_END                      As Long = 2&
Public Const FILE_BEGIN                    As Long = 0
Public Const FILE_ATTRIBUTE_DIRECTORY      As Long = &H10
Public Const FILE_SHARE_DELETE             As Long = &H4
Public Const FILE_FLAG_NO_BUFFERING        As Long = &H20000000
Public Const SEE_MASK_INVOKEIDLIST         As Long = &HC
Public Const SEE_MASK_NOCLOSEPROCESS       As Long = &H40
Public Const SEE_MASK_FLAG_NO_UI           As Long = &H400
Public Const FO_DELETE                     As Long = &H3
