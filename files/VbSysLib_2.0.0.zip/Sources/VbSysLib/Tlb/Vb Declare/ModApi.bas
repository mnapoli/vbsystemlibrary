Attribute VB_Name = "ModApi"
Option Explicit

Public Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long

Public Declare Function GetSecurityInfo Lib "advapi32.dll" (ByVal hObject As Long, ByVal ObjectType As Long, ByVal SecurityInformation As Long, ppsidOwner As Long, ppsidGroup As Long, ppDacl As Long, ppSacl As Long, ppSecurityDescriptor As Long) As Long
Public Declare Function LookupAccountSid Lib "advapi32.dll" Alias "LookupAccountSidA" (ByVal lpSystemName As String, ByVal Sid As Long, ByVal Name As String, cbName As Long, ByVal ReferencedDomainName As String, cbReferencedDomainName As Long, peUse As Long) As Long

Public Declare Function GetProcAddress Lib "kernel32" (ByVal hModule As Long, ByVal lpProcName As String) As Long

Public Declare Function WaitForSingleObject Lib "kernel32" (ByVal hHandle As Long, ByVal dwMilliseconds As Long) As Long


Public Declare Function lstrlenA Lib "kernel32.dll" (ByVal lpString As Long) As Long
Public Declare Function lstrcpyA Lib "kernel32.dll" (ByVal lpString1 As String, ByVal lpString2 As Long) As Long
Public Declare Function VirtualFreeEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, ByVal dwSize As Long, ByVal dwFreeType As Long) As Long
Public Declare Function VirtualAllocEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, ByVal dwSize As Long, ByVal flAllocationType As Long, ByVal flProtect As Long) As Long


Public Declare Function CreateToolhelp32Snapshot Lib "kernel32.dll" (ByVal dwFlags As Long, ByVal th32ProcessID As Long) As Long

Public Declare Function NtQuerySystemInformation Lib "Ntdll.dll" (ByVal SystemInformationClass As Long, ByVal SystemInformation As Long, ByVal SystemInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function NtSetSystemInformation Lib "Ntdll.dll" (ByVal SystemInformationClass As Long, ByVal SystemInformation As Long, ByVal SystemInformationLength As Long) As Long


Public Declare Function QueryPerformanceCounter Lib "kernel32" (lpPerformanceCount As Currency) As Long
Public Declare Function QueryPerformanceFrequency Lib "kernel32" (lpFrequency As Currency) As Long


Public Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInheritHandle As Long, ByVal dwProcessId As Long) As Long
Public Declare Function PostThreadMessageA Lib "user32" (ByVal idThread As Long, ByVal msg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
Public Declare Function TerminateProcess Lib "kernel32" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long
Public Declare Function GetExitCodeProcess Lib "kernel32" (ByVal hProcess As Long, lpExitCode As Long) As Long

Public Declare Function NtSuspendProcess Lib "Ntdll.dll" (ByVal hProc As Long) As Long
Public Declare Function NtResumeProcess Lib "Ntdll.dll" (ByVal hProc As Long) As Long


Public Declare Function GetCurrentProcessId Lib "kernel32.dll" () As Long
' D�finir la priorit� du processus
Public Declare Function SetPriorityClass Lib "kernel32" (ByVal hProcess As Long, ByVal dwPriorityClass As Long) As Long
Public Declare Function GetPriorityClass Lib "kernel32" (ByVal hProcess As Long) As Boolean

' Pour la taille d'un processus
Public Declare Function NtQueryInformationProcess Lib "Ntdll.dll" (ByVal ProcessHandle As Long, ByVal ProcessInformationClass As Long, ByVal ProcessInformation As Long, ByVal ProcessInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function ReadProcessMemory Lib "kernel32.dll" (ByVal hProcess As Long, ByVal lpBaseAddress As Long, ByVal lpBuffer As Long, ByVal nSize As Long, lpNumberOfBytesWritten As Long) As Long


' Fenetres
Public Declare Function GetWindow Lib "user32" (ByVal hWnd As Long, ByVal wCmd As Long) As Long

Public Declare Function GetDesktopWindow Lib "user32" () As Long
' WindowText
Public Declare Function GetWindowTextLength Lib "user32" Alias "GetWindowTextLengthA" (ByVal hWnd As Long) As Long
Public Declare Function GetWindowTextA Lib "user32" (ByVal hWnd As Long, ByVal lpString As String, ByVal cch As Long) As Long
Public Declare Function SetWindowTextA Lib "user32" (ByVal hWnd As Long, ByVal lpString As String) As Long
' WindowLong
Public Declare Function GetWindowLongA Lib "user32" (ByVal hWnd As Long, ByVal nIndex As Long) As Long
Public Declare Function SetWindowLongA Lib "user32" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long

Public Declare Function SetLayeredWindowAttributes Lib "user32" (ByVal hWnd As Long, ByVal crKey As Long, ByVal bAlpha As Byte, ByVal dwFlags As Long) As Boolean

Public Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long

Public Declare Function IsWindowVisible Lib "user32" (ByVal hWnd As Long) As Boolean
Public Declare Function IsWindowEnabled Lib "user32" (ByVal hWnd As Long) As Boolean
' Montrer la fen�tre
Public Declare Function ShowWindowA Lib "user32" Alias "ShowWindow" (ByVal hWnd As Long, ByVal nCmdShow As Long) As Long

Public Declare Function EnableWindow Lib "user32" (ByVal hWnd As Long, ByVal fEnable As Long) As Long
' Manipuler les menus d'une fen�tre
Public Declare Function GetSystemMenu Lib "user32" (ByVal hWnd As Long, ByVal bRevert As Long) As Long
Public Declare Function DrawMenuBar Lib "user32" (ByVal hWnd As Long) As Long
Public Declare Function GetMenuItemCount Lib "user32" (ByVal hMenu As Long) As Long
Public Declare Function RemoveMenu Lib "user32" (ByVal hMenu As Long, ByVal nPosition As Long, ByVal wFlags As Long) As Long

Public Declare Function GetClassNameA Lib "user32.dll" (ByVal hWnd As Long, ByVal lpClassName As String, ByVal nMaxCount As Long) As Long
' R�cup�re la fenetre parente
Public Declare Function GetParent Lib "user32" (ByVal hWnd As Long) As Long
' Savoir quel thread et quel processus ont cr�� une fenetre
Public Declare Function GetWindowThreadProcessId Lib "user32" (ByVal hWnd As Long, lpdwProcessId As Long) As Long

Public Declare Function GetModuleFileNameExA Lib "PSAPI.DLL" (ByVal hProcess As Long, ByVal hModule As Long, ByVal lpFileName As String, ByVal nSize As Long) As Long
Public Declare Function GetModuleHandleA Lib "kernel32" (ByVal lpModuleName As String) As Long
Public Declare Function EnumProcessModules Lib "PSAPI.DLL" (ByVal hProcess As Long, ByRef lphModule As Long, ByVal cb As Long, ByRef cbNeeded As Long) As Long

Public Declare Sub GetSystemInfo Lib "kernel32" (ByVal lpSystemInfo As Long)

Public Declare Function OpenThread Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInherit As Long, ByVal dwThreadId As Long) As Long
Public Declare Function SuspendThread Lib "kernel32" (ByVal hThread As Long) As Long
Public Declare Function ResumeThread Lib "kernel32" (ByVal hThread As Long) As Long
Public Declare Function GetExitCodeThread Lib "kernel32" (ByVal hThread As Long, lpExitCode As Long) As Long


Public Declare Function DeleteFileA Lib "kernel32" (ByVal lpFileName As String) As Long
' Propri�t�s d'un fichier
Public Declare Function PathFindExtensionA Lib "shlwapi" (ByVal pPath As String) As Long
' Attributs
Public Declare Function GetFileAttributesA Lib "kernel32.dll" (ByVal lpFileName As String) As Long
Public Declare Function SetFileAttributesA Lib "kernel32.dll" (ByVal lpFileSpec As String, ByVal dwFileAttributes As Long) As Long

Public Declare Function SHGetPathFromIDListA Lib "Shell32.dll" (ByVal pidl As Long, ByVal pszPath As String) As Long
Public Declare Function GetFileSizeEx Lib "kernel32" (ByVal hFile As Long, lpFileSize As Currency) As Boolean

Public Declare Function ImageList_Draw Lib "comctl32" (ByVal himl As Long, ByVal i As Long, ByVal hDCDest As Long, ByVal X As Long, ByVal Y As Long, ByVal Flags As Long) As Long
Public Declare Function DestroyIcon Lib "user32.dll" (ByVal hIcon As Long) As Boolean

Public Declare Function OpenProcessToken Lib "advapi32.dll" (ByVal ProcessHandle As Long, ByVal DesiredAccess As Long, TokenHandle As Long) As Long

Public Declare Function SHGetFileInfoA Lib "Shell32.dll" (ByVal pszPath As String, ByVal dwFileAttributes As Long, ByVal psfi As Long, ByVal cbFileInfo As Long, ByVal uFlags As Long) As Long

Public Declare Function GetWindowsDirectoryA Lib "kernel32" (ByVal lpBuffer As String, ByVal nSize As Long) As Long

Public Declare Function FindExecutableA Lib "Shell32.dll" (ByVal lpFile As String, ByVal lpDirectory As String, ByVal lpResult As String) As Long

Public Declare Function ExtractAssociatedIcon Lib "Shell32.dll" Alias "ExtractAssociatedIconA" (ByVal hInst As Long, ByVal lpIconPath As String, lpiIcon As Long) As Long

Public Declare Function ImageList_GetIcon Lib "comctl32.dll" (ByVal himl As Long, ByVal i As Long, ByVal Flags As Long) As Long

Public Declare Function GetVersionExA Lib "kernel32" (ByVal lpVersionInformation As Long) As Long

Public Declare Function GetFileVersionInfoSizeA Lib "Version.dll" (ByVal lptstrFilename As String, lpdwHandle As Long) As Long

Public Declare Sub RtlMoveMemory Lib "kernel32.dll" (ByVal Dest As Long, ByVal Source As Long, ByVal Length As Long)

