@Echo Off

RegSvr32 VbSysLib.dll