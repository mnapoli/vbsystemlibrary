Attribute VB_Name = "modAPI"
'---------------------------------------------------------------------------------------
' Module    : modAPI
' DateTime  : 22/11/2006 23:02
' Author    : Vb System Library
' Copyright : (C) 2007 L'�quipe Vb System Library
'              See "modPresentation" for more information
' Purpose   : Regroupe toutes les d�clarations d'API, de constantes et de types
'---------------------------------------------------------------------------------------

Option Explicit



'---------------------------------------------------------------------------------------
' Divers
Public Type POINTAPI
    X As Long
    Y As Long
End Type
Public Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long
Public Const MAX_PATH As Integer = 260
Public Declare Function GetSecurityInfo Lib "advapi32.dll" (ByVal hObject As Long, ByVal ObjectType As Long, ByVal SecurityInformation As Long, ppsidOwner As Long, ppsidGroup As Long, ppDacl As Long, ppSacl As Long, ppSecurityDescriptor As Long) As Long
Public Declare Function LookupAccountSid Lib "advapi32.dll" Alias "LookupAccountSidA" (ByVal lpSystemName As String, ByVal Sid As Long, ByVal Name As String, cbName As Long, ByVal ReferencedDomainName As String, cbReferencedDomainName As Long, peUse As Long) As Long
Public Const SE_KERNEL_OBJECT As Long = 6
Public Const OWNER_SECURITY_INFORMATION As Long = 1
Public Const GROUP_SECURITY_INFORMATION As Long = 2
' Manipuler la m�moire
Public Declare Sub CopyMemory Lib "kernel32.dll" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)
Public Declare Sub MoveMemory Lib "kernel32.dll" Alias "RtlMoveMemory" (Destination As Any, Source As Any, ByVal Length As Long)
Public Declare Function lstrlen Lib "kernel32.dll" Alias "lstrlenA" (ByVal lpString As Long) As Long
Public Declare Function lstrcpy Lib "kernel32.dll" Alias "lstrcpyA" (ByVal lpString1 As String, ByVal lpString2 As Long) As Long
' Pour lister les process, modules, threads
Public Declare Function CreateToolhelp32Snapshot Lib "kernel32.dll" (ByVal dwFlags As Long, ByVal th32ProcessID As Long) As Long
' Renvoie l'adresse du descripteur de tableau
Public Declare Function VarPtrArray Lib "msvbvm60.dll" Alias "VarPtr" (Arr() As Any) As Long
' Constante pour descripteur de tableau
Public Const FADF_AUTO = 1
Public Const FADF_FIXEDSIZE = 16
Public Const FADF_STATIC = 2
' Descripteur de tableau
Public Type SafeArray1d
    cDims As Integer        'nombre de dimensions
    fFeatures As Integer    'falgs
    cbElements As Long      'taille des elements
    cLocks As Long          'tableau non redimensionnable
    pvData As Long          'pointeur vers les donn�es du tableau
    cElements As Long       'nombre d'elements
    lLbound As Long         'limite basse
End Type
' Informations sur une plage m�moire
Public Type MEMORY_BASIC_INFORMATION ' 28 bytes
    BaseAddress         As Long     ' Adresse de la plage m�moire
    AllocationBase      As Long
    AllocationProtect   As Long
    RegionSize          As Long     ' Taille en octets de la plage m�moire
    State               As Long
    Protect             As Long     ' Protection d'acc�s � la plage m�moire
    lType               As Long
End Type
' Constantes pour lType
Public Const MEM_PRIVATE As Long = &H20000
Public Const MEM_COMMIT  As Long = &H1000
Public Declare Function VirtualQueryEx Lib "kernel32" (ByVal hProcess As Long, lpAddress As Any, lpBuffer As MEMORY_BASIC_INFORMATION, ByVal dwLength As Long) As Long
Public Declare Sub GetSystemInfo Lib "kernel32" (lpSystemInfo As SYSTEM_INFO)
Public Type SYSTEM_INFO ' 36 Bytes
    dwOemID                     As Long     ' Obsolete
    dwPageSize                  As Long
    lpMinimumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus petite accessible aux applications et DLL
    lpMaximumApplicationAddress As Long     ' Pointeur vers l'adresse m�moire la plus grande accessible aux applications et DLL
    dwActiveProcessorMask       As Long
    dwNumberOrfProcessors       As Long     ' Nombre de processeurs dans le systeme
    dwProcessorType             As Long
    dwAllocationGranularity     As Long
    wProcessorLevel             As Integer
    wProcessorRevision          As Integer
End Type

'---------------------------------------------------------------------------------------
' Processus
' Permet d'obtenir un handle d'un processus particulier
Public Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInheritHandle As Long, ByVal dwProcessId As Long) As Long
' Constantes d'acc�s aux processus
Public Const PROCESS_TERMINATE                  As Long = &H1
Public Const PROCESS_CREATE_THREAD              As Long = &H2
Public Const PROCESS_SET_SESSIONID              As Long = &H4
Public Const PROCESS_VM_OPERATION               As Long = &H8
Public Const PROCESS_VM_READ                    As Long = &H10
Public Const PROCESS_VM_WRITE                   As Long = &H20
Public Const PROCESS_DUP_HANDLE                 As Long = &H40
Public Const PROCESS_CREATE_PROCESS             As Long = &H80
Public Const PROCESS_SET_QUOTA                  As Long = &H100
Public Const PROCESS_SET_INFORMATION            As Long = &H200
Public Const PROCESS_QUERY_INFORMATION          As Long = &H400
Public Const PROCESS_READ_CONTROL               As Long = &H20000
Public Const SYNCHRONIZE                        As Long = &H100000
Public Const STANDARD_RIGHTS_REQUIRED           As Long = &HF0000
Public Const PROCESS_ALL_ACCESS                 As Long = (STANDARD_RIGHTS_REQUIRED Or SYNCHRONIZE Or &HFFF)
'------------------------------------
Public Declare Function TerminateProcess Lib "kernel32" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long
Public Declare Function GetExitCodeProcess Lib "kernel32" (ByVal hProcess As Long, lpExitCode As Long) As Long
Public Const STILL_ACTIVE = &H103
' Permet d'obtenir des infos sur les temps des processus
Public Declare Function GetProcessTimes Lib "kernel32" (ByVal hProcess As Long, lpCreationTime As Currency, lpExitTime As Currency, lpKernelTime As Currency, lpUserTime As Currency) As Long
' Renvoie le process courant
Public Declare Function GetCurrentProcess Lib "kernel32.dll" () As Long
' Enum�re les modules d'un processus
Public Declare Function EnumProcessModules Lib "PSAPI.DLL" (ByVal hProcess As Long, ByRef lphModule As Long, ByVal cb As Long, ByRef lpcbNeeded As Long) As Long
' D�finir la priorit� du processus
Public Declare Function SetPriorityClass Lib "kernel32" (ByVal hProcess As Long, ByVal dwPriorityClass As Long) As Long
' Constantes des priorit�s (6 niveaux de priorit�s)
Public Const IDLE_PRIORITY_CLASS            As Long = &H40      ' Basse
Public Const BELOW_NORMAL_PRIORITY_CLASS    As Long = &H4000    ' Inf�rieure � la normale
Public Const NORMAL_PRIORITY_CLASS          As Long = &H20      ' Normale
Public Const ABOVE_NORMAL_PRIORITY_CLASS    As Long = &H8000    ' Sup�rieure � la normale
Public Const HIGH_PRIORITY_CLASS            As Long = &H80      ' Haute
Public Const REALTIME_PRIORITY_CLASS        As Long = &H100     ' Temps r�el
' Pour la taille d'un processus
Public Declare Function GetProcessMemoryInfo Lib "PSAPI.DLL" (ByVal hProcess As Long, ppsmemCounters As PROCESS_MEMORY_COUNTERS, ByVal cb As Long) As Long
' NtQuerySystemInformation
Public Declare Function NtQuerySystemInformation Lib "Ntdll.dll" (ByVal SystemInformationClass As Long, ByVal SystemInformation As Long, ByVal SystemInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function NtQueryInformationProcess Lib "Ntdll.dll" (ByVal ProcessHandle As Long, ByVal ProcessInformationClass As Long, ByVal ProcessInformation As Long, ByVal ProcessInformationLength As Long, ReturnLength As Long) As Long
Public Declare Function ReadProcessMemory Lib "kernel32.dll" (ByVal hProcess As Long, ByVal lpBaseAddress As Long, ByVal lpBuffer As Long, ByVal nSize As Long, lpNumberOfBytesWritten As Long) As Long
Public Const STATUS_INFO_LENGTH_MISMATCH As Long = &HC0000004
Public Const STATUS_SUCCESS As Long = &H0&
Public Const SystemProcessesAndThreadsInformation As Long = 5&
Public Const ProcessSessionInformation As Long = 24&


'---------------------------------------------------------------------------------------
' Fenetres
Public Declare Function GetWindow Lib "user32" (ByVal hWnd As Long, ByVal wCmd As Long) As Long
Public Const GW_CHILD = 5
Public Const GW_HWNDNEXT = 2
Public Declare Function GetDesktopWindow Lib "user32" () As Long
Public Declare Function GetWindowTextLength Lib "user32" Alias "GetWindowTextLengthA" (ByVal hWnd As Long) As Long
Public Declare Function GetWindowText Lib "user32" Alias "GetWindowTextA" (ByVal hWnd As Long, ByVal lpString As String, ByVal cch As Long) As Long
Public Declare Function SetWindowText Lib "user32" Alias "SetWindowTextA" (ByVal hWnd As Long, ByVal lpString As String) As Long
Public Declare Function GetWindowLong Lib "user32" Alias "GetWindowLongA" (ByVal hWnd As Long, ByVal nIndex As Long) As Long
Public Declare Function SetWindowLong Lib "user32" Alias "SetWindowLongA" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
'renvoie les styles de la fen�tre
Public Const GWL_STYLE As Long = -16
'renvoie les styles �tendus de la fen�tre
Public Const GWL_EXSTYLE As Long = -20
' Pour la transparence
Public Const WS_EX_LAYERED = &H80000
Public Declare Function SetLayeredWindowAttributes Lib "user32" (ByVal hWnd As Long, ByVal crKey As Long, ByVal bAlpha As Byte, ByVal dwFlags As Long) As Boolean
Public Const LWA_COLORKEY = &H1
Public Const LWA_ALPHA = &H2
' Pour connaitre les dimensions et positions de la fenetre
Declare Function GetWindowRect Lib "user32" (ByVal hWnd As Long, lpRect As RECT) As Long
' Activer toujours la fen�tre au dessus des autres
Public Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Const SWP_NOSIZE = &H1
Public Const SWP_NOMOVE = &H2
Public Const HWND_TOP = 0
Public Const HWND_TOPMOST = -1
Public Const HWND_NOTOPMOST = -2
' Le placement d'une fenetre
Public Declare Function GetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpWndPl As WINDOWPLACEMENT) As Long
Public Declare Function SetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpWndPl As WINDOWPLACEMENT) As Long
Public Type WINDOWPLACEMENT
    Length As Long
    Flags As Long
    ShowCmd As Long
    ptMinPosition As POINTAPI
    ptMaxPosition As POINTAPI
    rcNormalPosition As RECT
End Type
' Fen�tre visible ou pas
Public Declare Function IsWindowVisible Lib "user32" (ByVal hWnd As Long) As Boolean
' Montrer la fen�tre
Public Declare Function ShowWindowA Lib "user32" Alias "ShowWindow" (ByVal hWnd As Long, ByVal nCmdShow As Long) As Long
' Constantes associ�es :
Public Const SW_HIDE = 0
Public Const SW_SHOWNORMAL = 1
Public Const SW_SHOWMINIMIZED = 2
Public Const SW_SHOWMAXIMIZED = 3
Public Const SW_MAXIMIZE = 3
Public Const SW_SHOWNOACTIVATE = 4
Public Const SW_SHOW = 5
Public Const SW_MINIMIZE = 6
Public Const SW_SHOWNA = 8
Public Const SW_RESTORE = 9


'---------------------------------------------------------------------------------------
' Modules
Public Declare Function GetModuleFileNameEx Lib "PSAPI.DLL" Alias "GetModuleFileNameExA" (ByVal hProcess As Long, ByVal hModule As Long, ByVal lpFileName As String, ByVal nSize As Long) As Long


'---------------------------------------------------------------------------------------
' Threads
Public Declare Function Thread32First Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Declare Function Thread32Next Lib "kernel32.dll" (ByVal hSnapshot As Long, ByRef lpte As THREADENTRY32) As Long
Public Const TH32CS_SNAPTHREAD As Long = &H4&
' Pour ouvrir un thread
Public Declare Function OpenThread Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInherit As Long, ByVal dwThreadId As Long) As Long
Public Const THREAD_ALL_ACCESS = &H1F03FF
' Suspendre un thread
Public Declare Function SuspendThread Lib "kernel32" (ByVal hThread As Long) As Long
Public Declare Function ResumeThread Lib "kernel32" (ByVal hThread As Long) As Long
' Le type thread
Public Type THREADENTRY32
    dwSize As Long              'taille de cette structure (� initialiser avant l'appel � Thread32First ou Thread32Next)
    cntUsage As Long            'nombre de r�f�rence au thread
    th32ThreadID As Long        'ID du thread
    th32OwnerProcessID As Long  'ID du processus qui a cr�� le thread
    tpBasePri As Long           'priorit� initiale
    tpDeltaPri As Long          'priorit� actuelle
    dwFlags As Long             'rien de d�fini
End Type


'---------------------------------------------------------------------------------------
' Les Fichiers
' Actions sur un fichier
Public Declare Function DeleteFile Lib "kernel32" Alias "DeleteFileA" (ByVal lpFileName As String) As Long
' Propri�t�s d'un fichier
Public Declare Function PathFindExtension Lib "shlwapi" Alias "PathFindExtensionA" (ByVal pPath As String) As Long
' Attributs
Public Declare Function GetFileAttributes Lib "kernel32.dll" Alias "GetFileAttributesA" (ByVal lpFileName As String) As Long
Public Declare Function SetFileAttributes Lib "kernel32.dll" Alias "SetFileAttributesA" (ByVal lpFileSpec As String, ByVal dwFileAttributes As Long) As Long
Public Const FILE_INVALID_ATTRIBUTES As Long = &HFFFFFFFF
Public Const FILE_ATTRIBUTE_NORMAL As Long = &H80
' Pour r�cup�rer des infos sur les fichiers
Public Declare Function GetFileVersionInfo Lib "Version.dll" Alias "GetFileVersionInfoA" (ByVal lptstrFilename As String, ByVal dwHandle As Long, ByVal dwLen As Long, lpData As Any) As Long
Public Declare Function GetFileVersionInfoSize Lib "Version.dll" Alias "GetFileVersionInfoSizeA" (ByVal lptstrFilename As String, lpdwHandle As Long) As Long
Public Declare Function VerQueryValue Lib "Version.dll" Alias "VerQueryValueA" (pBlock As Any, ByVal lpSubBlock As String, lplpBuffer As Any, puLen As Long) As Long
Public Type VS_FIXEDFILEINFO
    dwSignature As Long
    dwStrucVersion As Long
    dwFileVersionMS As Long
    dwFileVersionLS As Long
    dwProductVersionMS As Long
    dwProductVersionLS As Long
    dwFileFlagsMask As Long
    dwFileFlags As Long
    dwFileOS As Long
    dwFileType As Long
    dwFileSubtype As Long
    dwFileDateMS As Long
    dwFileDateLS As Long
End Type
' Un argument de type Enum permet l'apparition d'une liste de
' choix lors de la saisie de l'appel de fonction.
Public Enum mfFileInfo
  fileinfoCompanyName = 0
  fileinfoFileDescription = 1
  fileinfoFileVersion = 2
  fileinfoInternalName = 3
  fileinfoLegalCopyright = 4
  fileinfoOriginalFileName = 5
  fileinfoProductName = 6
  fileinfoProductVersion = 7
End Enum


'---------------------------------------------------------------------------------------
' Token Privileges
' R�cup�re et change les privil�ges
Public Declare Function AdjustTokenPrivileges Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal DisableAllPrivileges As Long, NewState As TOKEN_PRIVILEGES, ByVal BufferLength As Long, PreviousState As TOKEN_PRIVILEGES, ReturnLength As Long) As Long
Public Declare Function OpenProcessToken Lib "advapi32.dll" (ByVal ProcessHandle As Long, ByVal DesiredAccess As Long, TokenHandle As Long) As Long
Public Declare Function LookupPrivilegeValue Lib "advapi32.dll" Alias "LookupPrivilegeValueA" (ByVal lpSystemName As String, ByVal lpName As String, lpLuid As LUID) As Long
Public Declare Function GetTokenInformation Lib "advapi32.dll" (ByVal TokenHandle As Long, ByVal TokenInformationClass As Long, TokenInformation As Any, ByVal TokenInformationLength As Long, ReturnLength As Long) As Long
' D�claratios des Types
Public Type LUID
    LowPart As Long
    HighPart As Long
End Type
Public Type LUID_AND_ATTRIBUTES
    pLuid As LUID
    Attributes As Long
End Type
Public Type TOKEN_PRIVILEGES
    PrivilegeCount As Long
    TheLuid As LUID
    Attributes As Long
End Type
Public Type SID_IDENTIFIER_AUTHORITY
   Value(6) As Byte
End Type
Public Type SID_AND_ATTRIBUTES
   Sid          As Long
   Attributes   As Long
End Type
Public Type TOKEN_GROUPS
   GroupCount   As Long
   Groups(500)  As SID_AND_ATTRIBUTES
End Type
' D�claration des constantes
Public Const TOKEN_ASSIGN_PRIMARY = &H1
Public Const TOKEN_DUPLICATE = &H2
Public Const TOKEN_IMPERSONATE = &H4
Public Const TOKEN_QUERY = &H8
Public Const TOKEN_QUERY_SOURCE = &H10
Public Const TOKEN_ADJUST_PRIVILEGES = &H20
Public Const TOKEN_ADJUST_GROUPS = &H40
Public Const TOKEN_ADJUST_DEFAULT = &H80
Public Const TOKEN_ALL_ACCESS = TOKEN_ASSIGN_PRIMARY + TOKEN_DUPLICATE + TOKEN_IMPERSONATE + TOKEN_QUERY + TOKEN_QUERY_SOURCE + TOKEN_ADJUST_PRIVILEGES + TOKEN_ADJUST_GROUPS + TOKEN_ADJUST_DEFAULT
Public Const SE_DEBUG_NAME As String = "SeDebugPrivilege"
Public Const SE_PRIVILEGE_ENABLED = &H2
Public Const TOKEN_USER     As Long = 1
Public Const TOKEN_GROUPS   As Long = 2
