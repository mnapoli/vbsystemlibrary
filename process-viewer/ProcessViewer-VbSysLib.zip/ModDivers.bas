Attribute VB_Name = "ModDivers"
'   ProcessViewer-VbSysLib
' Visualisateur de processus.
' Copyright (C) 2007 - L'�quipe Vb System Library
'
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
'
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

' If you want to contact us, you can visit :
' http://vbsystemlibrary.free.fr/
' or send a mail at vbsystemlibrary@free.fr

Option Explicit

Public Declare Function GetParent Lib "user32" (ByVal hWnd As Long) As Long
Public Declare Function SetParent Lib "user32" (ByVal hWndChild As Long, ByVal hWndNewParent As Long) As Long
Public Declare Function InitCommonControls Lib "Comctl32.dll" () As Long
Public Declare Function ReleaseCapture Lib "user32" () As Long
Public Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long
Public Declare Function GetCurrentProcessId Lib "kernel32" () As Long
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Integer, lParam As Any) As Long

Public Type LVITEM
    mask As Long
    iItem As Long
    iSubItem As Long
    State As Long
    stateMask As Long
    pszText As String
    cchTextMax As Long
    iImage As Long
    lParam As Long
    iIndent As Long
End Type

Public Const LVM_FIRST = &H1000&

Public Const LVM_SETCOLUMNWIDTH = LVM_FIRST + 30
Public Const LVSCW_AUTOSIZE = -1

Public Const LVM_SETITEMTEXTA = (LVM_FIRST + 46)
Public Const LVM_GETITEMTEXT As Long = (LVM_FIRST + 45)

Public Const LVS_EX_FULLROWSELECT As Long = &H20
Public Const LVM_SETEXTENDEDLISTVIEWSTYLE As Long = (LVM_FIRST + 54)

Public Const LB_RESETCONTENT = &H184 'efface tous les elements de la liste
Public Const LB_SETSEL = &H185       'selectionne le

Public Const LVS_EX_GRIDLINES As Long = &H1
Public Const LVS_EX_CHECKBOXES As Long = &H4
Public Const LVM_GETITEMSTATE As Long = (LVM_FIRST + 44)
Public Const LVIS_STATEIMAGEMASK As Long = &HF000


Public Const WS_CHILD = &H40000000
Public Const WM_NCLBUTTONDOWN = &HA1
Public Const HTCAPTION = 2

Public Type POINTAPI
        X As Long
        Y As Long
End Type

Public Type WINDOWPLACEMENT
        Length As Long
        Flags As Long
        showCmd As Long
        ptMinPosition As POINTAPI
        ptMaxPosition As POINTAPI
        rcNormalPosition As RECT
End Type


Public Declare Function SetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpwndpl As WINDOWPLACEMENT) As Long
Public Declare Function GetWindowPlacement Lib "user32" (ByVal hWnd As Long, lpwndpl As WINDOWPLACEMENT) As Long


' Pour executer un fichier avec son extension
Private Declare Function ShellExecute Lib "Shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long

' Fonction pour ouvrir un fichier avec son programme associ�
Public Function ShellFile(ByVal File As String) As Long
    Dim clsFile As New clsFiles
    Dim Path As String
    Path = clsFile.GetPathFromFullPath(File)
    ShellFile = ShellExecute(0, vbNullString, File, vbNullString, Path, 1)
End Function



