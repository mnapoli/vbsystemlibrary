VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Begin VB.UserControl ProcInfo 
   AutoRedraw      =   -1  'True
   ClientHeight    =   7065
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   8250
   ClipControls    =   0   'False
   HasDC           =   0   'False
   ScaleHeight     =   7065
   ScaleWidth      =   8250
   Begin VB.Frame FrameMod 
      BackColor       =   &H80000014&
      Height          =   4335
      Left            =   3840
      TabIndex        =   2
      Top             =   6480
      Visible         =   0   'False
      Width           =   5415
      Begin ComctlLib.ListView LvModules 
         Height          =   3975
         Left            =   120
         TabIndex        =   3
         Top             =   240
         Width           =   5175
         _ExtentX        =   9128
         _ExtentY        =   7011
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         _Version        =   327682
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   4
         BeginProperty ColumnHeader(1) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Nom"
            Object.Width           =   2293
         EndProperty
         BeginProperty ColumnHeader(2) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            SubItemIndex    =   1
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "ID"
            Object.Width           =   529
         EndProperty
         BeginProperty ColumnHeader(3) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            SubItemIndex    =   2
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Adresse m�moire"
            Object.Width           =   2117
         EndProperty
         BeginProperty ColumnHeader(4) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            SubItemIndex    =   3
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Fichier"
            Object.Width           =   7056
         EndProperty
      End
   End
   Begin VB.Frame FramePerf 
      BackColor       =   &H80000014&
      Height          =   4815
      Left            =   1800
      TabIndex        =   4
      Top             =   1560
      Visible         =   0   'False
      Width           =   6135
      Begin ComctlLib.ListView LvPerf 
         Height          =   2415
         Left            =   120
         TabIndex        =   8
         Top             =   2400
         Width           =   5895
         _ExtentX        =   10398
         _ExtentY        =   4260
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   0   'False
         HideSelection   =   -1  'True
         HideColumnHeaders=   -1  'True
         _Version        =   327682
         ForeColor       =   -2147483640
         BackColor       =   -2147483628
         Appearance      =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   11.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   2
         BeginProperty ColumnHeader(1) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Propri�t�"
            Object.Width           =   6244
         EndProperty
         BeginProperty ColumnHeader(2) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            Alignment       =   1
            SubItemIndex    =   1
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Valeur"
            Object.Width           =   2540
         EndProperty
      End
      Begin ProcViewer_VbSysLib.Graph GrphCPU 
         Height          =   1935
         Left            =   120
         TabIndex        =   7
         Top             =   240
         Width           =   5895
         _ExtentX        =   10398
         _ExtentY        =   3413
         Max             =   101
         Min             =   -1
         NBValues        =   60
         BackColor       =   0
         ForeColor       =   49152
         TextColor       =   49152
         Border          =   1
         Title           =   ""
         Legend          =   -1  'True
         Smooth          =   0   'False
      End
   End
   Begin VB.Timer TimerRunning 
      Enabled         =   0   'False
      Interval        =   500
      Left            =   3360
      Top             =   120
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   4080
      Top             =   120
   End
   Begin VB.CommandButton BtnAttach 
      Caption         =   "Attacher / D�tacher"
      Height          =   375
      Left            =   4800
      TabIndex        =   0
      Top             =   240
      Width           =   1575
   End
   Begin VB.CommandButton BtnProperties 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Voir les proprietes"
      Height          =   375
      Left            =   4080
      MaskColor       =   &H00FFFFFF&
      TabIndex        =   10
      Top             =   4680
      UseMaskColor    =   -1  'True
      Width           =   2175
   End
   Begin VB.CommandButton BtnOpenForlder 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Ouvrir le dossier contenant"
      Height          =   375
      Left            =   4080
      MaskColor       =   &H00FFFFFF&
      TabIndex        =   11
      Top             =   4200
      UseMaskColor    =   -1  'True
      Width           =   2175
   End
   Begin VB.CommandButton BtnSeachGoogl 
      BackColor       =   &H00FFFFFF&
      Caption         =   "Rechercher sur google"
      Height          =   375
      Left            =   4080
      MaskColor       =   &H00FFFFFF&
      TabIndex        =   12
      Top             =   5160
      UseMaskColor    =   -1  'True
      Width           =   2175
   End
   Begin VB.Frame FrameInfo 
      BackColor       =   &H80000014&
      Height          =   4575
      Left            =   360
      TabIndex        =   1
      Top             =   1080
      Width           =   6015
      Begin ComctlLib.ListView LvInfo 
         Height          =   735
         Left            =   120
         TabIndex        =   9
         Top             =   240
         Width           =   1575
         _ExtentX        =   2778
         _ExtentY        =   1296
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         HideColumnHeaders=   -1  'True
         _Version        =   327682
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         Appearance      =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   2
         BeginProperty ColumnHeader(1) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Propri�t�"
            Object.Width           =   2540
         EndProperty
         BeginProperty ColumnHeader(2) {0713E8C7-850A-101B-AFC0-4210102A8DA7} 
            SubItemIndex    =   1
            Key             =   ""
            Object.Tag             =   ""
            Text            =   "Valeur"
            Object.Width           =   2540
         EndProperty
      End
   End
   Begin ComctlLib.TabStrip TabStrip1 
      Height          =   5295
      Left            =   240
      TabIndex        =   5
      Top             =   600
      Width           =   6375
      _ExtentX        =   11245
      _ExtentY        =   9340
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   3
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Informations"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Performances"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Modules"
            Key             =   ""
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
   Begin VB.Label LbCaption 
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   120
      TabIndex        =   6
      Top             =   120
      Width           =   4575
   End
   Begin VB.Shape Shape1 
      BorderColor     =   &H8000000C&
      BorderWidth     =   2
      Height          =   375
      Left            =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   375
   End
   Begin ComctlLib.ImageList ImgList 
      Left            =   6600
      Top             =   480
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      UseMaskColor    =   0   'False
      _Version        =   327682
   End
   Begin VB.Image ImgDLL 
      Height          =   240
      Left            =   6720
      Picture         =   "ProcInfo.ctx":0000
      Top             =   120
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Menu mnuModule 
      Caption         =   "Module"
      Begin VB.Menu mnuUnloadModule 
         Caption         =   "D�charger"
      End
      Begin VB.Menu mnuSeparator 
         Caption         =   "-"
      End
      Begin VB.Menu mnuRefreshModulesList 
         Caption         =   "Rafraichir la liste"
      End
   End
End
Attribute VB_Name = "ProcInfo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'   ProcessViewer-VbSysLib
' Visualisateur de processus.
' Copyright (C) 2007 - L'�quipe Vb System Library
'
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
'
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

' If you want to contact us, you can visit :
' http://vbsystemlibrary.free.fr/
' or send a mail at vbsystemlibrary@free.fr

Option Explicit

Private Declare Function SHObjectPropertiesW Lib "shell32" Alias "#178" (ByVal hWndOwner As Long, ByVal uFlags As Long, ByVal lpstrName As Long, ByVal lpstrParameters As Long) As Long

Private CurrentIndex        As Integer
Private Pid                 As Long
Private Running             As Boolean
Private Proc                As Process
Private IsAttached          As Boolean

Private Handle              As Long
Private ParentHwnd          As Long
Private ParentParentHwnd    As Long

Private WinP                As WINDOWPLACEMENT

Private File                As File
Private CpuUse              As clsProcessCpuUsage
Private ProcInfo            As ProcessInfo
Private Modules             As clsModules

Private Const LbCpuUsage         As String = "Utilisation du processeur"
Private Const LbMemoryUsage      As String = "Utilisation m�moire vive"
Private Const LbPeakMemoryUsage  As String = "Pic utilisation m�moire vive"
Private Const LbSWAP             As String = "Utilisation fichier SWAP"
Private Const LbPeakSWAP         As String = "Pic utilisation fichier SWAP"
Private Const LbQuotaPaged       As String = "R�serve pagin�e"
Private Const LbQuotaNonPaged    As String = "R�serve non pagin�e"
Private Const LbPageFault        As String = "Erreurs de pages"
Private Const LbThreadCount      As String = "Nombre de thread"
Private Const LbHandleCount      As String = "Nombre de handle"

Private Const LbName             As String = "Nom du processus"
Private Const LblProgram         As String = "Programme"
Private Const LbUserName         As String = "Nom d'utilisateur"
Private Const LbID               As String = "ID du processus"
Private Const LbPriority         As String = "Priorit�"
Private Const LbParent           As String = "Processus parent"
Private Const LbImFile           As String = "Chemin de l'executable"
Private Const LbDesc             As String = "Description"

Private Const LbCompanyName      As String = "Soci�t�"
Private Const LbInternalName     As String = "Nom Interne"
Private Const LbCopyright        As String = "Copyright"
Private Const LbOriginalFileName As String = "Nom d'origine"

Public Event ProcessTerminated(ByVal Pid As Long)
Public Event Detach(ByVal bDetach As Boolean)


' D�fini le processID
Public Property Let ProcessId(ByVal NewPid As Long)

    If NewPid <> Pid Then
        Running = False
        DoEvents
        Pid = NewPid
        GetInfo
        LbCaption.Caption = Proc.Name
        ShowInfo
        Running = True
        TimerRunning.Enabled = Running
        Timer1.Enabled = Running
    End If
    
End Property

Public Property Get hWnd() As Long
    hWnd = UserControl.hWnd
End Property
Public Property Get Attached() As Boolean
    Attached = IsAttached
End Property
Public Property Let Attached(Value As Boolean)
    IsAttached = Value
End Property

' R�cup�re les infos
Private Sub GetInfo()

    Set Proc = Nothing
    Set File = Nothing
    Set CpuUse = Nothing
    Set Modules = Nothing

    Set Proc = New Process
    
    Proc.GetProcessByID Pid, True

    If Pid > 4 Then
        Set File = New File
        Set CpuUse = New clsProcessCpuUsage
        GrphCPU.Clear
        CpuUse.SetPid Pid
        GrphCPU.Unit = "%"
        GrphCPU.Refresh
        File.GetFileByFullPath Proc.FileName
        ProcInfo = clsProcesses.GetProcessInfos(Pid)
    End If
    
End Sub


' Affiche un tabstrip
Private Sub ShowTab()

    FrameInfo.Visible = CurrentIndex = 1
    FramePerf.Visible = CurrentIndex = 2
    FrameMod.Visible = CurrentIndex = 3
    BtnProperties.Visible = CurrentIndex = 1
    BtnSeachGoogl.Visible = CurrentIndex = 1
    BtnOpenForlder.Visible = CurrentIndex = 1

End Sub

' Affiche les infos
Private Sub ShowInfo()

    Dim FileAdvancedInfos As FileVersionInfos
    Dim ProcessBasicInfos As ProcessBasicInformations

    ProcessBasicInfos = clsProcesses.GetProcessBasicInfos(Proc.ParentProcessID)
    If Pid > 4 Then
        FileAdvancedInfos = clsFiles.GetFileVersionInfos(File.FullPath)
        SetLvItemText LvInfo, FileAdvancedInfos.FileDescription, LvInfo.ListItems(LbDesc).Index, 1
        SetLvItemText LvInfo, FileAdvancedInfos.ProductName, LvInfo.ListItems(LblProgram).Index, 1
        SetLvItemText LvInfo, Proc.FileName, LvInfo.ListItems(LbImFile).Index, 1
        SetLvItemText LvInfo, FileAdvancedInfos.OriginalFileName, LvInfo.ListItems(LbOriginalFileName).Index, 1
        SetLvItemText LvInfo, FileAdvancedInfos.CompanyName, LvInfo.ListItems(LbCompanyName).Index, 1
        SetLvItemText LvInfo, FileAdvancedInfos.InternalName, LvInfo.ListItems(LbInternalName).Index, 1
        SetLvItemText LvInfo, FileAdvancedInfos.Copyright, LvInfo.ListItems(LbCopyright).Index, 1
    End If
    
    SetLvItemText LvInfo, ProcessBasicInfos.ProcessName, LvInfo.ListItems(LbParent).Index, 1
    SetLvItemText LvInfo, Proc.Name, LvInfo.ListItems(LbName).Index, 1
    SetLvItemText LvInfo, Proc.UserName, LvInfo.ListItems(LbUserName).Index, 1
    SetLvItemText LvInfo, Pid, LvInfo.ListItems(LbID).Index, 1
    SetLvItemText LvInfo, clsProcesses.GetPriorityName(Proc.Priority), LvInfo.ListItems(LbPriority).Index, 1
   
    Call SendMessage(LvInfo.hWnd, LVM_SETCOLUMNWIDTH, 1, LVSCW_AUTOSIZE)
    
    RefreshModulesList
    
End Sub


' Rafraichit la liste des modules
Private Sub RefreshModulesList()

    If Pid <= 4 Then LvModules.ListItems.Clear: Exit Sub
    
    Dim ModList()   As ModuleInfos
    Dim Item        As ListItem
    Dim T           As Long
    Dim ModCount    As Long
        
    Set Modules = Nothing
    Set Modules = New clsModules
    
    Set LvModules.SmallIcons = Nothing
    ImgList.ListImages.Clear
    ImgList.ListImages.Add , "DLL", ImgDLL.Picture
    Set LvModules.SmallIcons = ImgList
    
    ModCount = Modules.CreateModuleList(Pid, ModList)
    LockWindowUpdate LvModules.hWnd

    LvModules.ListItems.Clear
    ' Vide le listview
    For T = 0 To ModCount
        ' Ajoute les items
        Set Item = LvModules.ListItems.Add(, "Module" + Str$(ModList(T).hModule), ModList(T).ModuleName)
        Item.SubItems(1) = ModList(T).ModuleID
        Item.SubItems(2) = ModList(T).lpBaseOfDll
        Item.SubItems(3) = ModList(T).ExeFile
        Item.SmallIcon = ImgList.ListImages(1).Key
    Next T
    
    Call SendMessage(LvModules.hWnd, LVM_SETCOLUMNWIDTH, 0, LVSCW_AUTOSIZE)
    LockWindowUpdate 0&

End Sub

Private Sub BtnAttach_Click()
    
    If IsAttached = True Then
        RaiseEvent Detach(True)
        GetWindowPlacement UserControl.hWnd, WinP
        ParentHwnd = GetParent(UserControl.hWnd)
        ParentParentHwnd = GetParent(ParentHwnd)
        SetParent UserControl.hWnd, ParentParentHwnd
        Shape1.Visible = True
        IsAttached = False
    Else
        Shape1.Visible = False
        RaiseEvent Detach(False)
        SetParent UserControl.hWnd, ParentHwnd
        IsAttached = True
        SetWindowPlacement UserControl.hWnd, WinP
    End If

End Sub

Private Sub BtnOpenForlder_Click()
    Shell "Explorer.exe /Select," & GetLvItemText(LvInfo, LvInfo.ListItems(LbImFile).Index, 1), vbNormalFocus
End Sub

Private Sub BtnProperties_Click()
    SHObjectPropertiesW UserControl.hWnd, &H2, StrPtr(GetLvItemText(LvInfo, LvInfo.ListItems(LbImFile).Index, 1)), 0&
End Sub

Private Sub BtnSeachGoogl_Click()
    ShellFile "http://www.google.fr/search?hl=fr&q=" & GetLvItemText(LvInfo, LvInfo.ListItems(LbName).Index, 1)
End Sub

'deplacement du control qand il est detach�
Private Sub LbCaption_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 1 Then
        If IsAttached = False Then
            Call ReleaseCapture
            Call SendMessage(UserControl.hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
        End If
    End If
End Sub

Private Sub LblSwap_Click()

End Sub

' Affiche le menu contextuel
Private Sub LvModules_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 2 Then PopupMenu mnuModule
End Sub


' Menu rafraichir la liste
Private Sub mnuRefreshModulesList_Click()
    RefreshModulesList
End Sub


' D�charge le module de la m�moire
Private Sub mnuUnloadModule_Click()

    Dim Key         As String
    Dim hModule     As Long
    Dim Ret         As Long
    
    If LvModules.SelectedItem <> "" Then
        Key = LvModules.ListItems(LvModules.SelectedItem.Index).Key
        hModule = Val(Right$(Key, Len(Key) - Len("Module")))
        Ret = MsgBox("Voulez-vous vraiment d�charger ce module de la m�moire du processus ?", vbCritical Or vbDefaultButton2 Or vbOKCancel, "Attention")
        If Ret = vbOK Then
            Modules.UnLoadModuleFromProcess Pid, , hModule
        End If
    End If
    DoEvents
    ' Rafraichit la liste
    RefreshModulesList
End Sub

' Change de menu
Private Sub TabStrip1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    CurrentIndex = TabStrip1.SelectedItem.Index
    UserControl_Resize
    If Pid > 0 Then ShowTab
End Sub


' Rafraichissement
Private Sub Timer1_Timer()
    
    Dim Cpu     As Double
    Dim sTmp    As String
    
    Timer1.Enabled = False
    
    If Running = True And (Pid > 4) Then
        Cpu = CpuUse.GetCpuUsage
        GrphCPU.AddValue CLng(Cpu)
        If CurrentIndex = 2 Then
            Proc.RefreshInfos
            ProcInfo = clsProcesses.GetProcessInfos(Pid)
            SetLvItemText LvPerf, Round(Cpu, 2) & " %", LvPerf.ListItems(LbCpuUsage).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.WorkingSetSize / 1024, "### ### Ko"), LvPerf.ListItems(LbMemoryUsage).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.PeakWorkingSetSize / 1024, "### ### Ko"), LvPerf.ListItems(LbPeakMemoryUsage).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.PagefileUsage / 1024, "### ### Ko"), LvPerf.ListItems(LbSWAP).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.PeakPagefileUsage / 1024, "### ### Ko"), LvPerf.ListItems(LbPeakSWAP).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.QuotaPagedPoolUsage / 1024, "### ### Ko"), LvPerf.ListItems(LbQuotaPaged).Index, 1
            SetLvItemText LvPerf, Format(Proc.MemoryInfos.QuotaNonPagedPoolUsage / 1024, "### ### Ko"), LvPerf.ListItems(LbQuotaNonPaged).Index, 1
            SetLvItemText LvPerf, Str(ProcInfo.ThreadCount), LvPerf.ListItems(LbThreadCount).Index, 1
            SetLvItemText LvPerf, Str(ProcInfo.HandleCount), LvPerf.ListItems(LbHandleCount).Index, 1
            SetLvItemText LvPerf, Str(Proc.MemoryInfos.PageFaultCount), LvPerf.ListItems(LbPageFault).Index, 1
        End If
    End If
             '
        'GrphCpu.Refresh

    Timer1.Enabled = Running
    
End Sub


Private Sub TimerRunning_Timer()
    
    
    TimerRunning.Enabled = False
    
    If VbSysLib.IsProcessRunning(Pid) = False Then
        If Pid > 4 And Running = True Then
            Running = False
            'RaiseEvent ProcessTerminated(Proc.Id)
        End If
    End If
    
    TimerRunning.Enabled = Running

End Sub

' Initialisation
Private Sub UserControl_Initialize()

    CurrentIndex = 1
    
    GrphCPU.AntiAlias = False
    GrphCPU.Legend = False
    GrphCPU.Smooth = False
    
    IsAttached = True
    
    LvPerf.ListItems.Add , LbCpuUsage, LbCpuUsage
    LvPerf.ListItems.Add , LbMemoryUsage, LbMemoryUsage
    LvPerf.ListItems.Add , LbPeakMemoryUsage, LbPeakMemoryUsage
    LvPerf.ListItems.Add , LbSWAP, LbSWAP
    LvPerf.ListItems.Add , LbPeakSWAP, LbPeakSWAP
    LvPerf.ListItems.Add , LbPageFault, LbPageFault
    LvPerf.ListItems.Add , LbQuotaPaged, LbQuotaPaged
    LvPerf.ListItems.Add , LbQuotaNonPaged, LbQuotaNonPaged
    LvPerf.ListItems.Add , LbThreadCount, LbThreadCount
    LvPerf.ListItems.Add , LbHandleCount, LbHandleCount
    
    LvInfo.ListItems.Add , LbName, LbName
    LvInfo.ListItems.Add , LblProgram, LblProgram
    LvInfo.ListItems.Add , LbUserName, LbUserName
    LvInfo.ListItems.Add , LbID, LbID
    LvInfo.ListItems.Add , LbPriority, LbPriority
    LvInfo.ListItems.Add , LbParent, LbParent
    LvInfo.ListItems.Add , LbImFile, LbImFile
    LvInfo.ListItems.Add , LbDesc, LbDesc
    LvInfo.ListItems.Add , LbOriginalFileName, LbOriginalFileName
    LvInfo.ListItems.Add , LbCompanyName, LbCompanyName
    LvInfo.ListItems.Add , LbInternalName, LbInternalName
    LvInfo.ListItems.Add , LbCopyright, LbCopyright

    Call SendMessage(LvPerf.hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, ByVal -1)
    Call SendMessage(LvModules.hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, ByVal -1)
    Call SendMessage(LvInfo.hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, LVS_EX_FULLROWSELECT, ByVal -1)
    
End Sub


Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 1 Then
        If IsAttached = False Then
            Call ReleaseCapture
            Call SendMessage(UserControl.hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
        End If
    End If
End Sub

' Redimensionnement
Private Sub UserControl_Resize()

    On Error GoTo ErrExit
    
    LockWindowUpdate UserControl.hWnd
    
    TabStrip1.Move 100, 600, UserControl.ScaleWidth - 200, UserControl.ScaleHeight - (700)

    Select Case CurrentIndex
        Case 1
            FrameInfo.Move TabStrip1.Left + 90, TabStrip1.Top + 400, TabStrip1.Width - 180, TabStrip1.Height - (400 + 120 + (380 + (BtnOpenForlder.Height * 3)))
            LvInfo.Move 60, 140, FrameInfo.Width - 110, FrameInfo.Height - 400
            BtnProperties.Move UserControl.ScaleWidth - BtnProperties.Width - 240, FrameInfo.Top + FrameInfo.Height + 110 ' (240 + (BtnOpenForlder.Height * 2))
            BtnSeachGoogl.Move UserControl.ScaleWidth - BtnProperties.Width - 240, FrameInfo.Top + FrameInfo.Height + (330 + (BtnOpenForlder.Height * 2))
            BtnOpenForlder.Move UserControl.ScaleWidth - BtnProperties.Width - 240, FrameInfo.Top + FrameInfo.Height + (220 + (BtnOpenForlder.Height))
        Case 2
            FramePerf.Move TabStrip1.Left + 90, TabStrip1.Top + 400, TabStrip1.Width - 180, TabStrip1.Height - (400 + 120)
            LvPerf.Move 120, LvPerf.Top, FramePerf.Width - 200, FramePerf.Height - LvPerf.Top - 120
            LvPerf.ColumnHeaders(1).Width = LvPerf.Width - 2500
            GrphCPU.Width = LvPerf.Width
        Case 3
            FrameMod.Move TabStrip1.Left + 90, TabStrip1.Top + 400, TabStrip1.Width - 180, TabStrip1.Height - (400 + 120)
            LvModules.Move 60, 140, FrameMod.Width - 110, FrameMod.Height - 200
    End Select
    
    Shape1.Move 0, 0, UserControl.ScaleWidth, UserControl.ScaleHeight
    BtnAttach.Left = UserControl.ScaleWidth - BtnAttach.Width - 120
    DoEvents
    UserControl.Refresh

ErrExit:
    LockWindowUpdate 0&
End Sub

' D�chargement
Private Sub UserControl_Terminate()
    Running = False
    Set File = Nothing
    Set Proc = Nothing
    Set CpuUse = Nothing
    Set Modules = Nothing
End Sub

Private Sub SetLvItemText(ByRef Lv As ListView, ByVal s As String, ByVal iItem As Integer, ByVal iSubItem As Integer)
    
    Dim Litem As LVITEM
    
    Litem.iItem = iItem
    Litem.iSubItem = iSubItem
    Litem.cchTextMax = 255
    Litem.pszText = Space$(255)

    Call SendMessage(Lv.hWnd, LVM_GETITEMTEXT, iItem - 1, Litem)
    
    If Left(Litem.pszText, Len(s)) <> s Then
        Litem.pszText = s
        Call SendMessage(Lv.hWnd, LVM_SETITEMTEXTA, iItem - 1, Litem)
    End If

End Sub
Private Function GetLvItemText(ByRef Lv As ListView, ByVal iItem As Integer, ByVal iSubItem As Integer) As String
    
    Dim Litem As LVITEM
    
    Litem.iItem = iItem
    Litem.iSubItem = iSubItem
    Litem.cchTextMax = 255
    Litem.pszText = Space$(255)

    Call SendMessage(Lv.hWnd, LVM_GETITEMTEXT, iItem - 1, Litem)
    GetLvItemText = Litem.pszText

End Function

