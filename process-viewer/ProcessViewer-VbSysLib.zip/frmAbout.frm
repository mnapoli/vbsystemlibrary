VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "A propos de ProcessViewer-VbSysLib"
   ClientHeight    =   3300
   ClientLeft      =   2340
   ClientTop       =   1935
   ClientWidth     =   5730
   ClipControls    =   0   'False
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00FF0000&
   Icon            =   "frmAbout.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2277.718
   ScaleMode       =   0  'User
   ScaleWidth      =   5380.766
   Begin VB.PictureBox picIcon 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      ClipControls    =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   840
      Left            =   120
      Picture         =   "frmAbout.frx":5C1A
      ScaleHeight     =   589.96
      ScaleMode       =   0  'User
      ScaleWidth      =   589.96
      TabIndex        =   1
      Top             =   120
      Width           =   840
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "OK"
      Default         =   -1  'True
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   465
      Left            =   4245
      TabIndex        =   0
      Top             =   2640
      Width           =   1260
   End
   Begin VB.Label lblViolent_Ken 
      AutoSize        =   -1  'True
      Caption         =   "Violent_Ken"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   3525
      MouseIcon       =   "frmAbout.frx":6844
      MousePointer    =   99  'Custom
      TabIndex        =   8
      Top             =   2040
      Width           =   840
   End
   Begin VB.Label lblMadmatt 
      AutoSize        =   -1  'True
      Caption         =   "MadMatt"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   2565
      MouseIcon       =   "frmAbout.frx":6996
      MousePointer    =   99  'Custom
      TabIndex        =   7
      Top             =   2040
      Width           =   630
   End
   Begin VB.Label lblSebdraluorg 
      AutoSize        =   -1  'True
      Caption         =   "Sebdraluorg"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   195
      Left            =   1365
      MouseIcon       =   "frmAbout.frx":6AE8
      MousePointer    =   99  'Custom
      TabIndex        =   6
      Top             =   2040
      Width           =   870
   End
   Begin VB.Label Label1 
      Caption         =   "D�veloppeurs :"
      ForeColor       =   &H00000000&
      Height          =   195
      Left            =   600
      TabIndex        =   5
      Top             =   1800
      Width           =   1155
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      BorderStyle     =   6  'Inside Solid
      Index           =   1
      X1              =   84.515
      X2              =   5309.398
      Y1              =   1687.582
      Y2              =   1687.582
   End
   Begin VB.Label lblDescription 
      Alignment       =   2  'Center
      Caption         =   $"frmAbout.frx":6C3A
      ForeColor       =   &H00000000&
      Height          =   690
      Left            =   150
      TabIndex        =   2
      Top             =   1080
      Width           =   5445
   End
   Begin VB.Label lblTitle 
      Caption         =   "ProcessViewer-VbSysLib"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   360
      Left            =   1320
      TabIndex        =   4
      Top             =   360
      Width           =   3885
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      BorderWidth     =   2
      Index           =   0
      X1              =   98.6
      X2              =   5309.398
      Y1              =   1697.935
      Y2              =   1697.935
   End
   Begin VB.Label lblVbSysLib 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "VB System Library"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   -1  'True
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   270
      Left            =   1155
      MouseIcon       =   "frmAbout.frx":6D15
      MousePointer    =   99  'Custom
      TabIndex        =   3
      Top             =   2760
      Width           =   2070
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'   ProcessViewer-VbSysLib
' Visualisateur de processus.
' Copyright (C) 2007 - L'�quipe Vb System Library
'
' This library is free software; you can redistribute it and/or
' modify it under the terms of the GNU Lesser General Public
' License as published by the Free Software Foundation; either
' version 2.1 of the License, or (at your option) any later version.
'
' This library is distributed in the hope that it will be useful,
' but WITHOUT ANY WARRANTY; without even the implied warranty of
' MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
' Lesser General Public License for more details.

' You should have received a copy of the GNU Lesser General Public
' License along with this library; if not, write to the Free Software
' Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

' If you want to contact us, you can visit :
' http://vbsystemlibrary.free.fr/
' or send a mail at vbsystemlibrary@free.fr

Private Sub cmdOK_Click()
    Unload Me
End Sub

Private Sub Form_Initialize()
    Call InitCommonControls
End Sub

Private Sub lblMadmatt_Click()
    ShellFile "http://matthieu.napoli.neuf.fr"
End Sub

Private Sub lblSebdraluorg_Click()
    ShellFile "http://forum.zebulon.fr/blog/sebdraluorg/"
End Sub

Private Sub lblVbSysLib_Click()
    ShellFile "http://vbsystemlibrary.free.fr/"
End Sub

Private Sub lblViolent_Ken_Click()
    ShellFile "http://vbsystemlibrary.free.fr/user.php?ID=2"
End Sub
